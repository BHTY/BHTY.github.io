#define UINT_PTR UINT*
#define DWORD unsigned int
#define DWORD_PTR DWORD*

int newFrame = 1;
int healFlag = 1;

#define GDK_win	   
#define GDK_win32

#define MM_CALLBACK

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "gdk.h"
#include "music.h"
#include "VGA.h"
#include "tables.h"
#include "drawing.h"
#include "3d.h"
#include "joy.h"
#pragma comment (lib , "winmm.lib")

#ifdef USE_DRAWDIB
#pragma comment (lib , "Vfw32.lib")
#endif

#define drawvec(vec)    (drawline(vec.p1.x, vec.p1.y, vec.p2.x, vec.p2.y, vec.shade))
#define tracevec(vec, pnt)              (traceLine(vec.p1.x, vec.p1.y, vec.p2.x, vec.p2.y, pnt, vec.shade))

#define ID int
#define STATE int
#define Fighter 0
#define Laser 1
#define Heal 2
#define Obstacle 3
#define ToughFighter 4
#define Bomb 5
#define Shield 6

#define IDLE 0
#define FIRED 70 //# of frames until next firing

typedef struct Object {
        Entity entity;
        ID type;
        STATE state;
        Point vector;
        int health;
        void* next; //cast to Object*
} Object;


char colors[11] = {0x1F, 0x30, 0x03, 0x26, 0x68, 0x56, 0x40, 0x02, 0x2F, 0x2C, 0x28};

int index;

int v[4];
char b[4];
char oldB[4];

void (*mouse)(int*, char*);

Point camera;
Point correctedCamera;
Point tempPoint;

char* buffer;
char* tempBuffer;
short oldPalette[256];

int level = 1;
unsigned char lives = 3; //lives = 3;
int bombs = 3;
int tempNum;

int xOffset = 0;
int loop = 0;

int firing = 0;
int laserBar = 240;
int recharging = 0;
int shieldFrames = 0;
int health = 240;

int score = 0;
int linus;

int died = 0;

Object *root;
Object *next;

Point camera;
Point correctedCamera;
Point tempPoint;


int nextLevel() {
    int temp, _tmp, retval;
    retval = 0;
    temp = 0;

    for(_tmp = 0; _tmp < level; _tmp++){
        retval += 100 + temp;
        temp += 50;
    }

    return retval;
}

void __stdcall timerproc(
  HWND unnamedParam1,
  UINT unnamedParam2,
  UINT_PTR unnamedParam3,
  DWORD unnamedParam4
)
{
    newFrame = 1;
}

void __stdcall mmproc(UINT uTimerID, UINT uMsg, DWORD_PTR dwUser, DWORD_PTR dw, DWORD_PTR dw2){
    newFrame = 1;
        //timeSetEvent(17, 1, &mmproc, 0, TIME_CALLBACK_FUNCTION);
}


void fadeImage(){
    unsigned char R, G, B;
    double mul = 0.0;
    FILE* imageFp = fopen("assets\\gameover.bmp", "rb");
    unsigned char* imageContents = malloc(65078);
    fread(imageContents, 1, 65078, imageFp);

    memset(currentPalette, 0, 512);
    memcpy(back, imageContents + 1078, 64000);

    for(mul = 0.0; mul < 1.0; mul+=0.01){

        for(index = 0; index < 256; index++){
            B = (unsigned char)(imageContents[54 + index * 4] * mul) & 248;
            G = (unsigned char)(imageContents[55 + index * 4] * mul) & 248;
            R = (unsigned char)(imageContents[56 + index * 4] * mul) & 248;
            currentPalette[index] = (B >> 3) | (G << 2) | (R << 7);
        }

        memcpy(back, imageContents + 1078, 64000);
        flipbuffer();
        GDK_update();
        waitblank();

    }

    free(imageContents);
    fclose(imageFp);

    return;
}



Point generatePoint(int x, int y, int z) {
        Point new;

        new.x = x;
        new.y = y;
        new.z = z;

        return new;
}

Entity generateEntity(Shape* shape, Point position, int rot) {
        Entity new;
        new.shape = shape;
        new.pos = position;
        new.rot = rot;
        return new;
}



void deadAnim(){
    Object* cur, * nxt;
        int obj = 1;
        int frames = 105;
        int flash = 0;
        int line = 0;

    stop_music();
    init_music("sfx\\request");

    cur = root;// &root;

        cur->state = IDLE;
        cur->entity.pos.x = rand() % 40 - 20;
        cur->entity.pos.y = rand() % 40 - 20;
        cur->entity.pos.z = camera.z + 200 + rand() % 40 - 20;

        do {
                nxt = cur->next; // we're actually processing this one, which skips root

                //printf("Dereferencing %p of Type %d\n", nxt, nxt->type);

                if (nxt->type == Laser || nxt->type == Heal || nxt->type == Bomb || nxt->type == Shield || nxt->type == Bomb) {
                        //printf("Object %d is a Laser/Healing item, removing from list!\n", obj);
                        cur->next = nxt->next;
                        free(nxt);
                        continue;
                }
                else if (nxt->type == Fighter) {
                        nxt->state = IDLE;
                        nxt->entity.pos.x = rand() % 40 - 20;
                        nxt->entity.pos.y = rand() % 40 - 20;
                        nxt->entity.pos.z = camera.z + 200 + rand() % 40 - 20;
                        //printf("Object %d is a Fighter, resetting!\n", obj);
                }
                cur = cur->next;
                obj++;
        } while (cur->next);
        // flash screen
        health = 240;
        laserBar = 240;
        recharging = 0;
        shieldFrames = 0;

        while (frames) {

                if (flash) {
                        currentPalette[0] = 32736;
                }

                if (!flash) {
                        currentPalette[0] = 0;
                }

                frames--;
                flash = !flash;
                waitblank();
                //flipbuffer();

        for(; line < 100; line++){
            memcpy(lineBuffer, back + 320*(199-line), 320);
            memcpy(back + 320*(199-line), back + 320*line, 320);
            memcpy(back + 320*line, lineBuffer, 320);
        }

                lockBuffer(back);
                GDK_drawBits();
                GDK_update();
        }

        stop_music();
        init_music("sfx\\THUNDER2");

}

void clearScreen(){
    Object* cur, * nxt;
        int obj = 1;
        int frames = 0;//245;
        int flash = 0;
        int flag = 0;

        Shape *star, *fight;

        Entity battlestar;
        Entity fighter;

        Point craig, biff;

        Point cam = generatePoint(0, 0, 200);

        int startFlash = 0;

        star = loadShape("assets\\battlestar.obj");
        fight = loadShape("assets\\tie.obj");

        battlestar.shape = star;
        battlestar.pos = generatePoint(0, 0, 175);

        fighter.shape = fight;
        fighter.pos = generatePoint(0, 0, 640);//320

        stop_music();

        cur = root;

        cur = root;// &root;

        cur->state = IDLE;
        cur->entity.pos.x = rand() % 40 - 20;
        cur->entity.pos.y = rand() % 40 - 20;
        cur->entity.pos.z = camera.z + 200 + rand() % 40 - 20;

        do {
                nxt = cur->next; // we're actually processing this one, which skips root

                //printf("Dereferencing %p of Type %d\n", nxt, nxt->type);

                if (nxt->type == Laser || nxt->type == Heal || nxt->type == Bomb || nxt->type == Shield || nxt->type == Bomb) {
                        //printf("Object %d is a Laser/Healing item, removing from list!\n", obj);
                        cur->next = nxt->next;
                        free(nxt);
                        continue;
                }
                else if (nxt->type == Fighter) {
                        nxt->state = IDLE;
                        nxt->entity.pos.x = rand() % 40 - 20;
                        nxt->entity.pos.y = rand() % 40 - 20;
                        nxt->entity.pos.z = camera.z + 200 + rand() % 40 - 20;
                        //printf("Object %d is a Fighter, resetting!\n", obj);
                }
                cur = cur->next;
                obj++;
        } while (cur->next);
        // flash screen
        laserBar = 240;
        recharging = 0;
        shieldFrames = 0;
        //init_music("sfx\\CLEAR");

        /**while (frames) {

                if (flash) {
                        currentPalette[0] = 31775;
                }

                if (!flash) {
                        currentPalette[0] = 0;
                }

                frames--;
                flash = !flash;
                waitblank();
                flipbuffer();
                GDK_update();
                update_music();
        }**/
        //stop_music();


        memset(back, 0, 64000);
        currentPalette[0] = 0;

        init_music_no_callback("sfx\\fly");

        while(1){

            biff = fighter.pos;
                craig = biff;
                craig.z = fighter.pos.z >> 1;
                fighter.pos = craig;

            paintShape(&fighter, cam);
            paintShape(&battlestar, cam);

            fighter.pos = biff;



            if(!startFlash){
                if(cam.z > 258){
                    fighter.pos.z-=50;
                }
                //cam.z++;
                if(!flag){
                    cam.z+=1;
                    flag = 20;
                    battlestar.pos.z--;
                }
                else{
                    //cam.z+=2;
                    cam.z+=1;
                    flag--;
                }

            }

            if(cam.z >= 261 && !startFlash){ //261
                startFlash = 70;
                play_soundfx("sfx\\explode");
                battlestar.pos.x = 1000;
                battlestar.pos.y = 1000;
            }

            if(startFlash){

                if(currentPalette[0] == 0){currentPalette[0] = 32256;}
                else{currentPalette[0] = 0;}

                startFlash--;

                if(!startFlash){
                    currentPalette[0] = 0;
                    break;
                }

            }

            flipbuffer();
            waitblank();
            waitblank();
            GDK_update();
        }

        //MessageBox(NULL, "Hello, world!", "Biff", MB_OK);

        stop_music();
        stop_music();
        stop_music();
        stop_music();
        init_music("sfx\\THUNDER2");
        free(star);
        free(fight);
}


void scale(unsigned char* imagePtr, char* newPtr, int oldX, int oldY, int newX, int newY) {

        int i, p;
        int scaleFactorX = (oldX << 4) / newX;
        int scaleFactorY = (oldY << 4) / newY;
        int currentLine = 0;

        for (i = 0; i < newY; i++) {
                for (p = 0; p < newX; p++) {
                        newPtr[currentLine + p] = imagePtr[oldX * ((scaleFactorY * i) >> 4) + ((scaleFactorX * p) >> 4)];
                }

                currentLine += newX;
        }

}

void paint(unsigned char* bitmap, int x, int y, int sizeX, int sizeY) {
        int i, p;

		//printf("%p x:%d y:%d sx:%d sy:%d\n", bitmap, x, y, sizeX, sizeY);

        for (i = 0; i < sizeY; i++) {
                if ((y + i) < 200) {
                        memcpy(&back[320 * (y + i) + x], (x >= 0) ? (&bitmap[sizeX * i]) : (&bitmap[sizeX * i] + x) , ((sizeX + x) > 320) ? sizeX - x : sizeX);
                        //when to clamp lower bound of X
                }
                /**for (p = 0; p < sizeX; p++) {
                        plotpixel(x + p, y + i, bitmap[sizeX * i + p]);
                }**/
        }
}



void init(){
    FILE* fp;
    int ABC = 0;
    srand(GetTickCount());
    mouse = readMouse;
    mouse(v, b);

    fp = fopen("assets\\dat.bin", "rb");
    numbers = malloc(2496);
    fread(numbers, 1, 2496, fp);
    fclose(fp);
    timeBeginPeriod(1);

    camera.x = 0;
    camera.y = 0;
    camera.z = 0;

    entermode(0x13);
}

void debugLog(char* message){
    MessageBox(hwnd, message, "Starblazer", MB_OK);
}

typedef struct{
	signed int posX, posY;
	signed int vecX, vecY;
} star;

star genStar(){
	star STAR;
	STAR.posX = 160;
	STAR.posY = 100;

	STAR.vecX = rand() % 6 - 3;
	STAR.vecY = rand() % 4 - 2;

	return STAR;
}

void vPutchar(char charIndex, int posX, int posY, unsigned char COL){

	int pX, pY, tY, tX, cX, cY, offset, cI;
	unsigned char TMP;
	
	if(charIndex == 32){
		return;
	}

	if(charIndex == 42){
		cI = 12;
	}

	else if(charIndex >= 48 && charIndex <= 57){
		cI = charIndex - 48;
	}

	else if(charIndex >= 65 && charIndex <= 90){
		cI = 13 + (charIndex - 65);
	}
	
	offset = cI * 64;

	for(pY = 0; pY < 16; pY++){

		tY = posY + pY;
		cY = pY	>> 1;

		for(pX = 0; pX < 16; pX++){

			tX = posX + pX;
			cX = pX >> 1;
			TMP = numbers[offset + cY * 8 + cX];

			if(TMP){back[ 320*tY + tX  ] = COL;}
		}

	}

}

void vPuts(char* cstring, int pX, int pY, unsigned char color){
	while(*cstring){
		vPutchar(*cstring, pX, pY, color);
		cstring++;
		pX += 16;
	}
}

typedef struct{
	int score;
	char name[8];  
} score_record;

void swapRecords(score_record* xp, score_record* yp){
	score_record temp = *xp;
	*xp = *yp;
	*yp = temp;
}

void sortRecords(score_record* records, int numRecords){
	int i, j;

	for (i = 0; i < numRecords - 1; i++){
		for (j = 0; j < numRecords - i - 1; j++){
			if (records[j].score < records[j+1].score){
				swapRecords(&(records[j]), &(records[j+1]));
			}
		}
	}
}

void printRecord(score_record *record, int line){
	char textbuf[12];

	vPuts(record->name, 0, line << 4, 48);
	sprintf(textbuf, "%d00", record->score);
	vPuts(textbuf, 160, line << 4, 48);				  
}

#define CRASS 120

void inputName(){ //CONGRATULATIONS ON GETTING A HIGH SCORE! PLEASE ENTER YOUR NAME

}

void creditsSeq(){	
	int idx;
	unsigned char cR, cB, cG;			
	char* tempBuffer = malloc(64000);
	char* imageBuffer = malloc(65078);		   
	FILE* fp = fopen("assets\\will.bmp", "rb");

	fread(imageBuffer, 1, 65078, fp); 

	init_music_no_callback("sfx\\credits");			  

	//set palette
	for(idx = 0; idx < 1024; idx += 4){
		cB = imageBuffer[54 + idx] & 248;
		cG = imageBuffer[55 + idx] & 248;
		cR = imageBuffer[56 + idx] & 248;

		currentPalette[idx >> 2] = (cR << 7) | (cG << 2) | (cB >> 3);  
	}					   					

	//scale Will's image in
	for(idx = 1; idx <= 40; idx++){
		scale(imageBuffer + 1078, tempBuffer, 320, 200, idx << 3, idx + (idx << 2));
		paint(tempBuffer, 160 - (8 * idx) / 2, 100 - ((5 * idx) / 2), 8 * idx, 5 * idx);
		flipbuffer();
		GDK_update();
		waitblank();
	}

	//hold for 60 frames
	for(idx = 101; idx > 0; idx--){
		waitblank(); 
		GDK_update();
	}

	fclose(fp);

	flipbuffer(); //blank screen
	fp = fopen("assets\\p13ty.bmp", "rb");
	fread(imageBuffer, 1, 65078, fp);

	for(idx = 0; idx < 1024; idx += 4){
		cB = imageBuffer[54 + idx] & 248;
		cG = imageBuffer[55 + idx] & 248;
		cR = imageBuffer[56 + idx] & 248;

		currentPalette[idx >> 2] = (cR << 7) | (cG << 2) | (cB >> 3);  
	}

	for(idx = 200; idx > 0; idx--){
		paint(imageBuffer + 1078, 0, idx, 320, 200);
		flipbuffer();
		GDK_update();
		waitblank();
	}

	for(idx = 0; idx < 320; idx++){
		paint(imageBuffer + 1078, idx, 0, 320, 200);
		flipbuffer();
		GDK_update();
		waitblank();
	}

	fclose(fp);

	fp = fopen("assets\\madeline.bmp", "rb");
	fread(imageBuffer, 1, 65078, fp);

	for(idx = 0; idx < 1024; idx += 4){
		cB = imageBuffer[54 + idx] & 248;
		cG = imageBuffer[55 + idx] & 248;
		cR = imageBuffer[56 + idx] & 248;

		currentPalette[idx >> 2] = (cR << 7) | (cG << 2) | (cB >> 3);  
	}

	for(idx = 320; idx > 0; idx--){
		paint(imageBuffer + 1078, idx, 0, 320, 200);
		flipbuffer();
		GDK_update();
		waitblank();
	}

	for(idx = 60; idx > 0; idx--){
		waitblank();
	}

	fclose(fp);

	stop_music();
	free(imageBuffer);
	free(tempBuffer);

}

void creditsScreen(){
	int pp;
	int fSz;
	score_record *records;
	unsigned short savedPalette[256];
	star stars[CRASS];
	FILE* fp = fopen("sav.bin", "rb");
	fseek(fp, 0L, SEEK_END);
	fSz = ftell(fp);
	fseek(fp, 0L, SEEK_SET);
	records = malloc(fSz);
	fread(records, 1, fSz, fp);

	sortRecords(records, fSz/sizeof(score_record));

	memset(back, 0, 64000);
	memcpy(savedPalette, currentPalette, 512);
	currentPalette[255] = 65535;

	for(pp = 0; pp < CRASS; pp++){
		stars[pp] = genStar();
	}

	while(1){
		for(pp = 0; pp < CRASS; pp++){
			plotpixel(stars[pp].posX, stars[pp].posY, 255);
			stars[pp].posX += stars[pp].vecX;
			stars[pp].posY += stars[pp].vecY;

			if(stars[pp].posX < 0 || stars[pp].posX > 319 || stars[pp].posY < 0 || stars[pp].posY > 199){
				stars[pp] = genStar();
			}
		}

		vPuts("  TOP STARBLAZERS", 8, 0, 124);
		currentPalette[124] = rand() % 32767;										 

		for(pp = 0; pp < (fSz/sizeof(score_record)); pp++){
			printRecord(&(records[pp]), pp+1);
		}

		flipbuffer();
		GDK_update();
		waitblank();

		if(GDK_mouse.b1){
			waitblank();
			GDK_mouse.b1 = 0;
			GDK_update();
			return;
		}
	}

	memcpy(currentPalette, savedPalette, 512);
	fclose(fp);
	free(records);
}

char getKey(){
	char TMP = curKey;
	curKey = 0;
	return TMP;
}

void titleScreen(){
    int i;
    short R, G, B;

    FILE* fp = fopen("assets\\outfile.bmp", "rb");
    buffer = malloc(65078);

    tempBuffer = malloc(64000);
    memset(tempBuffer, 32, 64000);
    fread(buffer, 1, 65078, fp);

    //save old palette
    memcpy(oldPalette, currentPalette, 512);

    //set new palette
    for(index = 0; index < 256; index++){
        B = buffer[54 + index * 4] & 248;
        G = buffer[55 + index * 4] & 248;
        R = buffer[56 + index * 4] & 248;

        currentPalette[index] = (B >> 3) | (G << 2) | (R << 7);
    }

    //zoom in title screen

    #ifdef MM_CALLBACK
        timeSetEvent(14, 1, (LPTIMECALLBACK)&mmproc, 0, TIME_CALLBACK_FUNCTION | TIME_PERIODIC);
    #endif

    newFrame = 1;
    for(i = 1; i <= 40; i++){
        scale(buffer + 1078, tempBuffer, 320, 200, i << 3, i + (i << 2));
        paint(tempBuffer, 160 - (8 * i) / 2, 100 - ((5 * i) / 2), 8 * i, 5 * i);
        flipbuffer();
        //waitblank();

        while(!newFrame){
            GDK_update();
        }

        #ifndef MM_CALLBACK
            SetTimer(hwnd, 1, 1, &timerproc);
        #endif

        newFrame = 0;

        //GDK_update();
    }

    //wait for mouse to be clicked
    init_music("sfx\\BADSONG1");

    while(!b[1]){
		//printf("%d\n", getKey());
        GDK_update();
        mouse(v, b);
        update_music();
        waitblank();

        if(b[0]){ //credits

            while(b[0]){
                GDK_update();
                mouse(v, b);
            }

            stop_music();
            init_music("sfx\\CREDITS");
            creditsScreen();
            memcpy(back, buffer + 1078, 64000);
            //debugLog("Lead Developer (Game Logic, Graphics, etc.): Will Klees\nSound Programmer: Josh Piety\n\nAnd a very special thanks to: Madeline Gold");
            stop_music();
            init_music("sfx\\BADSONG1");
			flipbuffer();
        }

    }

    stop_music();

    //restore old palette
    memcpy(currentPalette, oldPalette, 512);
	free(buffer);
	free(tempBuffer);
	fclose(fp);
}

/*Object objectArray[16];
int allocatedObjects[16];

char discretionary[80];*/

void* allocateObject(){
    /*int currentIndex = 0;

    for(; currentIndex < 16; currentIndex++){
        if(allocatedObjects[currentIndex] == 0){
            allocatedObjects[currentIndex] = 1;
            //sprintf(discretionary, "Alloced object %d", currentIndex);
            //debugLog(discretionary);
            return &objectArray[currentIndex];
        }
    }

    return NULL;*/
    return malloc(sizeof(Object));
}

void freeObject(Object* ptr){
    /*int currentIndex = (ptr - &objectArray[0]);
    //sprintf(discretionary, "Freed object %d", currentIndex);
    //debugLog(discretionary);
    allocatedObjects[currentIndex] = 0;*/
    free(ptr);
}

Object* genObj(Entity entity, ID type, Point vector, Object* next) {
        Object* new = allocateObject();//malloc(sizeof(Object));
        new->entity = entity;
        new->type = type;
        new->state = IDLE;
        new->vector = vector;
        new->next = next;
        return new;
}

int __stdcall WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow){
//int main(){
    int cursorX, cursorY, firing, laserPosition, dir, flash;

    char message[128];
    char tempStr[128];
    
    char cursorPosition;
   	char HSname[8];	

    int frameStartTime;
    int frameEndTime;
    int freed;
    int oldb0;
	int fSz;
	FILE* fFp;
	score_record *records;
	score_record tempRecord;
	int idx;
	int hs;
	int elements;

    Vector line0;
    Vector line1;
    Vector line2;
    Vector line3;

    Object *curNext;

        Object* third;
        Object newObj;
        Object tempObj;
        Object* tempPtr;
        Object* nextItem;

        Object* cur;
        Object* curOld;
        Entity* curEnt;

		char c;

        FILE* fp;
        FILE* fp2;
        char* imageBuffer;

        int running = 1;
        int clearEnemies = 0;
		int frameTime = 0;


        int bombing = 0;

		int partner = 0;
		int lowest = 0;	


        Point pos = { 10, 10, 200 };
        Point pos2 = { -24, -24, 200 };
        Point basicVec = { 0, 0, 0 };
        Point laserVec = { 0, 0, -1 };
        Point bombVec = {0, 0, 3};

        Shape* tie = loadShape("assets\\tie.obj");
        Shape* bolt = loadShape("assets\\bolt.obj");
        Shape* heal = loadShape("assets\\heal.obj");
        Shape* bomb = loadShape("assets\\bomb.obj");
        Shape* shield = loadShape("assets\\shield.obj");

        third = genObj(generateEntity(tie, pos, 0), 0, basicVec, 0);
        next = genObj(generateEntity(tie, pos, 0), 0, basicVec, third);
        root = genObj(generateEntity(tie, pos2, 0), 0, basicVec, next);

    line0.shade = 31;
    line1.shade = 31;
    line2.shade = 31;
    line3.shade = 31;

	initCache();

	cursorPosition = 0;
	memset(HSname, 0, 8);

        newFrame = 1;

    nCmdShow_ = SW_SHOWNORMAL;
    hInstance_ = GetModuleHandle(NULL);

    init();
    titleScreen();

    init_music("sfx\\THUNDER2");

    while(running){

		frameStartTime = timeGetTime();
        //frameStartTime = GetTickCount();
        //draw walls
        line0.shade = colors[(level - 1) % 11];
        line1.shade = colors[(level - 1) % 11];
        line2.shade = colors[(level - 1) % 11];
        line3.shade = colors[(level - 1) % 11];

        //get wall coords
        line0.p1.x = 4 * (-5 * camera.y - 160) + 100; //160 and 4
        line0.p1.y = 4 * (-2 * camera.x - 100) + 100;
        line0.p2.x = 145;
        line0.p2.y = 85;

        line1.p1.x = 4 * (319 + (5 * camera.y) - 160) + 100; //160 and 4
        line1.p1.y = 4 * (2 * camera.x - 100) + 100;
        line1.p2.x = 175;
        line1.p2.y = 85;

        line2.p1.x = 4 * (4 * camera.y - 160) + 160;
        line2.p1.y = 4 * (199 + 2 * camera.x - 100) + 100;
        line2.p2.x = 145;
        line2.p2.y = 115;

        line3.p1.x = 175;
        line3.p1.y = 115;
        line3.p2.x = 4 * (319 - (4 * camera.y) - 160) + 160;
        line3.p2.y = 4 * (199 - 2 * camera.x - 100) + 100;

        drawvec(line0);
        drawvec(line1);
        drawvec(line2);
        drawvec(line3);

        drawline(145, 85, 145, 115, line0.shade);
        drawline(175, 85, 175, 115, line0.shade);
        drawline(145, 115, 175, 115, line0.shade);

        drawline(line2.p1.x + 10, line2.p1.y, line2.p2.x + 10, line2.p2.y, line0.shade);
        drawline(line3.p1.x - 10, line3.p1.y, line3.p2.x - 10, line3.p2.y, line0.shade);

        //right wall
        xOffset = 175 + (camera.z * 2 % 50);

        for(loop = 0; loop < 3; loop++){
            drawline(xOffset, tracevec(line1, xOffset), xOffset, tracevec(line3, xOffset), line0.shade);
            xOffset += 50;
        }

        //left wall
        xOffset = 145 - (camera.z * 2 % 50);

        for (loop = 0; loop < 3; loop++) {
            drawline(xOffset, tracevec(line0, xOffset), xOffset, tracevec(line2, xOffset), line0.shade);
            xOffset -= 50;
        }


        //draw all entities
        correctedCamera = camera;
                        correctedCamera.x = -(camera.x);
                        correctedCamera.y = -(camera.y);
                        correctedCamera.z = camera.z;

        cur = root;// &root;
                        curOld = root;// &root;

                        //firing = 0;

                        do {


                                curEnt = &(((Object*)cur)->entity);

                                 /**if(!cur->type && (curEnt->pos.z - 100 < camera.z)){
                                    //cursorX = curEnt->center.x;
                                    //cursorY = curEnt->center.y;
                                    firing = 1;
                                 }**/

                                if (curEnt->shape->numLines > 25 || curEnt->shape->numLines < 1) {
                                        //debugMenu();
                                        break;
                                }

                                paintShape(curEnt, correctedCamera);

                                curOld = cur;
                                if ((Object*)cur->next) { cur = (Object*)cur->next; }
                        } while ((Object*)curOld->next);


        //draw fired lasers
                        if (firing) {

                                if (laserPosition) {
                                        drawline(30, 50, cursorX, cursorY, 51);
                                        drawline(290, 50, cursorX, cursorY, 51);
                                }

                                if (!laserPosition) {
                                        drawline(30, 150, cursorX, cursorY, 51);
                                        drawline(290, 150, cursorX, cursorY, 51);
                                }

                                laserPosition = !laserPosition;
                        }

                        //draw targeting cursor
                        drawline(cursorX - 10, cursorY - 10, cursorX - 10, cursorY + 10, 31);
                        drawline(cursorX + 10, cursorY - 10, cursorX + 10, cursorY + 10, 31);

                        drawline(cursorX - 10, cursorY - 10, cursorX - 5, cursorY - 10, 31);
                        drawline(cursorX + 10, cursorY - 10, cursorX + 5, cursorY - 10, 31);

                        drawline(cursorX - 10, cursorY + 10, cursorX - 5, cursorY + 10, 31);
                        drawline(cursorX + 10, cursorY + 10, cursorX + 5, cursorY + 10, 31);

                        //plotpixel(cursorX, cursorY, 31);

                        //draw laser bar
                        drawline(130, 5, 190, 5, 0x1F);
                        drawline(130, 15, 190, 15, 31);
                        drawline(130, 5, 130, 15, 31);
                        drawline(190, 5, 190, 15, 31);

                        //fill firing meter up to capacity
                        for (index = 2051; index < 4930; index += 320) {
                                memset(back + index, 0x24, (laserBar > 3) ? (laserBar / 4 - 1) : 0);
                        }


        //draw health meter
                        drawline(130, 195, 190, 195, 31);
                        drawline(130, 185, 190, 185, 31);
                        drawline(130, 195, 130, 185, 31);
                        drawline(190, 195, 190, 185, 31);

                        //fill health bar
                        for (index = 59651; index < 62530; index += 320) {
                                memset(back + index, 0x20, (health > 3) ? (health / 4 - 1) : 0);
                        }


        //draw laser cannons
                        drawline(0, 35, 10, 35, 0x28); //top-left
                        drawline(0, 65, 10, 65, 0x28);
                        drawline(10, 35, 10, 65, 0x28);
                        drawline(10, 45, 20, 45, 0x28);
                        drawline(10, 55, 20, 55, 0x28);
                        drawline(20, 45, 20, 55, 0x28);
                        drawline(20, 50, 30, 50, 0x28);

                        drawline(0, 135, 10, 135, 0x28); //bottom-left
                        drawline(0, 165, 10, 165, 0x28);
                        drawline(10, 135, 10, 165, 0x28);
                        drawline(10, 145, 20, 145, 0x28);
                        drawline(10, 155, 20, 155, 0x28);
                        drawline(20, 145, 20, 155, 0x28);
                        drawline(20, 150, 30, 150, 0x28);

                        drawline(319, 35, 309, 35, 0x28); //top-right
                        drawline(319, 65, 309, 65, 0x28);
                        drawline(309, 35, 309, 65, 0x28);
                        drawline(309, 45, 299, 45, 0x28);
                        drawline(309, 55, 299, 55, 0x28);
                        drawline(299, 45, 299, 55, 0x28);
                        drawline(299, 50, 289, 50, 0x28);

                        drawline(319, 135, 309, 135, 0x28); //bottom-right
                        drawline(319, 165, 309, 165, 0x28);
                        drawline(309, 135, 309, 165, 0x28);
                        drawline(309, 145, 299, 145, 0x28);
                        drawline(309, 155, 299, 155, 0x28);
                        drawline(299, 145, 299, 155, 0x28);
                        drawline(299, 150, 289, 150, 0x28);

                        //draw screen crack
                        if (health < 76) {
                                drawline(30, 0, 40, 50, 31);
                                drawline(40, 50, 70, 80, 31);
                                drawline(70, 80, 120, 85, 31);
                                drawline(120, 85, 160, 100, 31);
                                drawline(160, 100, 100, 130, 31);
                                drawline(100, 130, 80, 160, 31);
                                drawline(80, 160, 20, 170, 31);
                                drawline(20, 170, 0, 192, 31);
                                drawline(160, 100, 215, 140, 31);
                                drawline(215, 140, 180, 155, 31);
                                drawline(180, 155, 220, 200, 31);
                                drawline(160, 100, 215, 85, 31);
                                drawline(215, 85, 200, 70, 31);
                                drawline(200, 70, 215, 50, 31);
                                drawline(215, 50, 319, 40, 31);

                                if(healFlag){
                                    healFlag = 0;
                                    play_soundfx("sfx\\trek22");
                                }
                        }
                        else{
                            healFlag = 1;
                        }

                        //draw score
                        putscore(score, 0, 0);

                        //draw lives
                        if (lives && lives <= 5) {
                                for (linus = 200; linus < 200 + lives * 10; linus += 10) {
                                        blitmap(numbers + 704, linus, 186, 8, 8);
                                }
                        }

                        else if (lives > 5){
                            blitmap(numbers + 704, 200, 186, 8, 8);
                            blitmap(numbers + 640, 210, 186, 8, 8);

                            if(lives > 9){
                                blitmap(numbers + (64 * (lives/10)), 220, 186, 8, 8);
                                blitmap(numbers + (64 * (lives%10)), 230, 186, 8, 8);
                            }
                            else{
                                blitmap(numbers + (64 * lives), 220, 186, 8, 8);
                            }

                        }

                        for (linus = 120; linus > 120 - (bombs * 8); linus -= 8) {
                                blitmap(numbers + 768, linus, 186, 8, 8);
                        }

                        if (flash) {
                                flash--;
                                if(!flash){currentPalette[0] = 0;}
                        }

                        if (shieldFrames) {
                                /**outp(0x3c8, 0);
                                outp(0x3c9, 0);
                                outp(0x3c9, 0);
                                outp(0x3c9, (char)(shieldFrames / 7));**/
                                currentPalette[0] = shieldFrames/16;

                        }

                update_music();
                //game logic
        memcpy(oldB, b, 4);
                mouse(v, b);
                cursorX = v[0];
                cursorY = v[1];

                if (shieldFrames) {
                        shieldFrames--;
                }

                if (bombing) {
                    play_soundfx("sfx\\explode");
                cur = root;
                if (root->type == 0) {
                        root->state = IDLE;
                       root->entity.pos.x = rand() % 40 - 20;
                        root->entity.pos.y = rand() % 40 - 20;
                        root->entity.pos.z = camera.z + 220 + rand() % 40 - 20;

                        score++;

                        if (score % 250 == 0) {
                                lives++;
                                play_soundfx("sfx\\trek4");
                        }
                }
                while (cur->next) {
                        nextItem = (Object*)cur->next;
                        if (nextItem->type == 0) {

                                nextItem->state = IDLE;
                                nextItem->entity.pos.x = rand() % 40 - 20;
                                nextItem->entity.pos.y = rand() % 40 - 20;
                                nextItem->entity.pos.z = camera.z + 220 + rand() % 40 - 20;

                                score++;

                                if (score % 250 == 0) {
                                        lives++;
                                    play_soundfx("sfx\\trek4");
                                }
                       } else if (nextItem->type == Bomb) {
                        Object *curNext = nextItem->next;
                        free(nextItem);
                        cur->next = curNext;
                        continue;
                       }
                       cur = nextItem;
                }
                bombing = 0;
        }


        cur = root;
        curOld = root;
        clearEnemies = 0;

        do {

                        curEnt = &(((Object*)cur)->entity);
                        freed = 0;

                        /**if(!cur->type){
                            cursorX = curEnt->center.x;
                            cursorY = curEnt->center.y;
                        }**/

                        if (!freed && cur->type == Bomb && curEnt->pos.z - camera.z > 100) {
                            // BOOM
                            currentPalette[0] = 31744;
                            flash = 10;
                            bombing = 1;
                            nextItem = cur->next;
                            free(curOld->next);
                            curOld->next = nextItem;
                            freed = 1;
                         }

                        if (!freed && (cur->type == Shield) && (camera.z >= (curEnt->pos.z - 16))) {
                                if (abs(curEnt->center.x - 160) < 80 && abs(curEnt->center.y - 100) < 80) {
                                        shieldFrames = 490;
                                        play_soundfx("sfx\\trek4");
                                }
                                nextItem = cur->next;
                                freeObject(curOld->next);
                                curOld->next = nextItem;
                                freed = 1;
                        }

                        if (!freed && cur->type == Heal && (camera.z >= (curEnt->pos.z - 16))) {
                                if (abs(curEnt->center.x - 160) < 80 && abs(curEnt->center.y - 100) < 80) {

                                play_soundfx("sfx\\trek4");
                                        if (health < 240) {
                                                if (health <= 220) {
                                                        health += 20;
                                                }
                                                else {
                                                        health += (240 - health);
                                                }
                                                currentPalette[0] = 31;
                                                flash = 1;
                                        }
                                }
                                nextItem = cur->next;
                                freeObject(curOld->next);
                                curOld->next = nextItem;
                                freed = 1;
                        }

                            if (!freed && !cur->type && (curEnt->pos.z - camera.z) < 100) { //within close range of player?

                                if (!cur->state) {

                                            //generate vector

                                        /**tempObj = generateObject(generateEntity(bolt, generatePoint(curEnt->pos.x, curEnt->pos.y, curEnt->pos.z), 0), 1, laserVec, cur->next); //spawn object
                                        cur->next = malloc(sizeof(Object));
                                        memcpy(cur->next, &tempObj, sizeof(Object));**/

                                        cur->next = genObj(generateEntity(bolt, generatePoint(curEnt->pos.x, curEnt->pos.y, curEnt->pos.z), 0), 1, laserVec, cur->next);

                                        cur->state = FIRED;
                                        play_soundfx("sfx\\trek1");
                                }

                                if (cur->state) {
                                        cur->state--;
                                }
                        }

                        if (!freed && cur->type == Laser && ((camera.z >= curEnt->pos.z - 16) || (camera.z == curEnt->pos.z - 15))) {
                                //if laser bolt, impacted player
                                //debugLog("Breakpoint hit!");
                                if (!shieldFrames && abs(curEnt->center.x - 160) < 80 && abs(curEnt->center.y - 100) < 80) {
                                        health -= 15;
                                        currentPalette[0] = 32256;
                                        /**outp(0x3c8, 0);
                                        outp(0x3c9, 255);
                                        outp(0x3c9, 32);
                                        outp(0x3c9, 0);**/
                                        flash = 1;
                                        play_soundfx("sfx\\trek12");
                                }

                                /**if (!cur->next) { //last object
                                        curOld->next = 0;
                                        break;
                                }
                                if (cur->next) { //not the last object
                                        tempPtr = cur->next;
                                        *cur = generateObject(tempPtr->entity, tempPtr->type, tempPtr->vector, tempPtr->next);
                                        continue;
                                }**/
                                nextItem = cur->next;
                                freeObject(curOld->next);
                                curOld->next = nextItem;
                                freed = 1;

                        }

                        if (!freed && camera.z >= curEnt->pos.z - 16 && !cur->type) { //gen

                                //debugLog("How did I get here?");

                                //if ( abs(curEnt->pos.x - camera.x) < 15 && abs(curEnt->pos.y - camera.y) < 15) {
                                if (!shieldFrames && abs(curEnt->center.x - 160) < 80 && abs(curEnt->center.y - 100) < 80) {
                                        health -= 10;
                                        /**outp(0x3c8, 0);
                                        outp(0x3c9, 255);
                                        outp(0x3c9, 32);
                                        outp(0x3c9, 0);**/
                                        flash = 1;
                                        play_soundfx("sfx\\trek12");
                                }

                                cur->state = IDLE;
                                cur->entity.pos.x = rand() % 40 - 20;
                                cur->entity.pos.y = rand() % 40 - 20;
                                cur->entity.pos.z = camera.z + 200 + rand() % 40 - 20;

                        }

                        if (!freed && !cur->type && firing && abs(curEnt->center.x - cursorX) < curEnt->size && abs(curEnt->center.y - cursorY) < curEnt->size) { //are the transformed center coordinates of the object equal to the coordinates of the mo

                                //debugLog("DIRECT HIT!");

                                //create explosion point effect - blast it into bits
                                play_soundfx("sfx\\LASER");

                                //respawn object
                                cur->state = IDLE;
                                cur->entity.pos.x = rand() % 40 - 20;
                                cur->entity.pos.y = rand() % 40 - 20;
                                cur->entity.pos.z = camera.z + 220 + rand() % 40 - 20;

                                score++;

                                if (score % 250 == 0) {
                                        lives++;
                                }

                                currentPalette[0] = 992;
                                flash = 1;
                        }


                        curEnt->pos.x += cur->vector.x;
                        curEnt->pos.y += cur->vector.y;
                        curEnt->pos.z += cur->vector.z;

                        curNext = (Object*)(freed ? curOld : cur)->next;
                        curOld = freed ? curOld : cur;
                        if(curNext){cur = curNext;}
                        else{break;}

                        /*curOld = cur;
                        if ((Object*)cur->next) { cur = (Object*)cur->next; }
                        else { break; }*/
                } while ((Object*)curOld->next);

                //generate healing item
                tempNum = rand() % 6000;

                if (tempNum < 5) {
                        /**tempObj = generateObject(generateEntity(heal, generatePoint(rand() % 40 - 20, rand() % 40 - 20, camera.z + 200 + rand() % 40 - 20), 0), Heal, basicVec, root.next);
                        root.next = malloc(sizeof(Object));
                        memcpy(root.next, &tempObj, sizeof(Object));**/
                        root->next = genObj(generateEntity(heal, generatePoint(rand() % 40 - 20, rand() % 40 - 20, camera.z + 200 + rand() % 40 - 20), 0), Heal, basicVec, root->next);
                }

                if (tempNum > 4 && tempNum < 10) { //spawn shield
                        root->next = genObj(generateEntity(shield, generatePoint(rand() % 40 - 20, rand() % 40 - 20, camera.z + 200 + rand() % 40 - 20), 0), Shield, basicVec, root->next);
                }

                //check if health is gone
                if (health <= 0) {
                        if (lives == 0) {
                                running = 0;
                                died = 1;
                        }
                        else {
                                lives--;
                                deadAnim();
                        }
                }

                //next level?
                /*if(GDK_mouse.b2){
                    score = nextLevel();
                }*/

                if ((score >= nextLevel())) {

                        clearScreen();

                        root->next = genObj(generateEntity(tie, generatePoint(rand() % 40 - 20, rand() % 40 - 20, camera.z + 200 + rand() % 40 - 20), 0), 0, basicVec, root->next);

                        level++;

                        if(level == 2){
                            if(bombs < 3){
                                bombs = 3;
                            }
                            else if(bombs < 5){
                                bombs++;
                            }
                        }

                        if(level == 3 || level == 4){
                            if(bombs < 2){
                                bombs = 2;
                            }
                            else if(bombs < 5){
                                bombs++;
                            }
                        }

                        if(level == 5){
                            if(bombs < 5){bombs++;}
                        }
                        //change color
                        //continue;
                }


        //move ship
                if (cursorX < 20 && camera.x < 20) {
                        camera.x += 2;
                }
                if (cursorX > 300 && camera.x > -20) {
                        camera.x -= 2;
                }
                if (cursorY < 20 && camera.y < 20) {
                        camera.y += 2;
                }
                if (cursorY > 180 && camera.y > -20) {
                        camera.y -= 2;
                }

                if (firing) {
                        laserBar--;
                        if (laserBar == 0) {
                                firing = 0;
                                recharging = 1;
                        }
                }

                if (!firing && laserBar < 240) {
                        laserBar++;
                        if (laserBar == 120) {
                                recharging = 0;
                        }
                }

                if (b[1] && !recharging) {
                        firing = 1;
                }
                else {
                        firing = 0;
                }

                if (b[0] > oldb0 && bombs) {
                    root->next = genObj(generateEntity(bomb, generatePoint(-camera.x, -camera.y, camera.z+2), 0), Bomb, bombVec, root->next);
                    bombs--;
                    play_soundfx("sfx\\tng");
                }
                oldb0 = b[0];

                camera.z++;
                flipbuffer();
        GDK_update();
        //waitblank();

        while(!newFrame){
            GDK_update();
            //debugLog("HOWWWW");
        }

        #ifndef MM_CALLBACK
            //SetTimer(hwnd, 1, 1, &timerproc);
        #endif

        newFrame = 0;

		if( (frameTime = (timeGetTime() - frameStartTime)) > 30){
			 //printf("%d miliseconds since beginning of frame\n", frameTime);
		}

	}

    stop_music();

    if(died){ 
		//load high score file - if we're larger than ANY of them...		
		fFp = fopen("sav.bin", "rb"); 					   
		fseek(fFp, 0L, SEEK_END);						   
		fSz = ftell(fFp);								   
		fseek(fFp, 0L, SEEK_SET);						   
		records = malloc((fSz < 4*sizeof(score_record)) ? (fSz+sizeof(score_record)) : fSz);	   
		fread(records, 1, fSz, fFp);
		fclose(fFp);
		hs = 0;																		

		for(idx = 0; idx < (elements = fSz/sizeof(score_record)); idx++){
			if(records[idx].score < score){
				hs = 1;
			}											  						   
		}

		if(hs || (fSz < (sizeof(score_record) * 4))){
			//display credits
			creditsSeq();

			//input name

			while(1){

				vPuts(" CONGRATULATIONS ON ", 0, 0, 123);
				vPuts("GETTING A HIGH SCORE", 0, 16, 123);
				vPuts("    PLEASE ENTER    ", 0, 32, 123);
				vPuts("     YOUR NAME      ", 0, 48, 123);	

				vPuts(HSname, 0, 64, 124);
				vPutchar('*', cursorPosition * 16, 80, 124);

				c = getKey();

				if(c == 8 && cursorPosition > 0){
					cursorPosition--;
				}
				else if(c == 13){
					break;
				}
				else if(c >= 65 && c <= 90 && cursorPosition < 8){
					HSname[cursorPosition] = c;
					cursorPosition++;
				}

				flipbuffer();
				GDK_update();
				waitblank();
				currentPalette[123] = rand() % 32767;
			
			}

			fFp = fopen("sav.bin", "wb");

			//today's record
			strcpy(tempRecord.name, HSname);
			tempRecord.score = score;

			//now, check if there's an available slot
			if(elements < 4){  //if there is, just slot the new high score in and sort
				records[elements] = tempRecord;		 
				fwrite(records, sizeof(score_record), elements+1, fFp);
			}

			else{ //if not, just replace the lowest score and we're golden
				lowest = 0x7FFFFFFF;
				partner = 0;

				for(idx = 0; idx < elements; idx++){
					if(records[idx].score < lowest){
						lowest = records[idx].score;
						partner = idx; //index of lowest score
					}
				}

				//printf("Record %d (%s) was the lowest with %d points\n", partner, records[partner].name, records[partner].score);
				records[partner] = tempRecord;	 
				//printf("Overwritten!\n");
				fwrite(records, sizeof(score_record), elements, fFp);
				//printf("File changes committed!\n");
			}
			
			fclose(fFp);					
		}

        init_music_no_callback("sfx\\GAMEOVER");
        /*sprintf(message, "You've been Starblazed! Your final score was %d00", score);
        MessageBox(hwnd, message, "GAME OVER", MB_OK);*/

        fadeImage();

        while(!GDK_mouse.b1){
            GDK_update();
        }		  
    }

    DestroyWindow(hwnd);
    PostQuitMessage(0);

}
