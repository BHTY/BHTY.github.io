void readMouse(int v[4], char b[4]) {
        memset(b, 4, 0);
        memset(v, 16, 0);

        b[1] = GDK_mouse.b1;
        b[0] = GDK_mouse.b2;
        v[0] = GDK_mouse.x;
        v[1] = GDK_mouse.y;
}
