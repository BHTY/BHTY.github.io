#include <vfw.h>

void* backBits;
int globalHeight;
int globalWidth;
int globalBpp;
int windowWidth, windowHeight;
float mouseFactorX, mouseFactorY;
BITMAPINFO bmi;
        RECT rectScreen;


typedef struct GDK_mouseStatus{
    int x, y;
    char b1;
    char b2;
} GDK_mouseStatus;

JOYINFO joypos;
int joyUsed = 0;

unsigned long centerX, centerY, topX, topY, bottomX, bottomY;

#define RGB16(R, G, B)  ((R << 10) + (G << 5) + B)

int getX(int rawX){
    if(rawX > centerX){
        return 160 + 160 * (float)(rawX - centerX)/(topX - centerX);
    }else if(rawX < centerX){
        return 160 - 160 * (float)(centerX - rawX)/(centerX - bottomX);
    }
    return 160;
}

int getY(int rawY){
    if(rawY > centerY){
        return 100 + 100 * (float)(rawY - centerY)/(topY - centerY);
    }else if(rawY < centerY){
        return 100 - 100 * (float)(centerY - rawY)/(centerY - bottomY);
    }
    return 100;
}


#ifdef GDK_win
    HBITMAP backBitmap;
    HPALETTE hPalette;
    POINT p;

    GDK_mouseStatus GDK_mouse;

    HWND hwnd;
    WNDCLASS wc;
    MSG Msg;

    HINSTANCE hInstance_;
    int nCmdShow_;



#include <mmsystem.h>

WAVEFORMATEX wfx;
HWAVEOUT hWaveOut = 0;
void* sndBuffer;
void* sndBackBuffer;
MMTIME t;
WAVEHDR header;
int sz;
int stopMusicCalled = 0;

void* EXPLODEBUFFER;
void* LASERBUFFER;
void* TNGBUFFER;
void* TREK1BUFFER;
void* TREK4BUFFER;
void* TREK12BUFFER;
void* TREK22BUFFER;

void* EXPLODESZ;
void* LASERSZ;
void* TNGSZ;
void* TREK1SZ;
void* TREK4SZ;
void* TREK12SZ;
void* TREK22SZ;

VOID initCache(){
	FILE* fp;
	int currentSize;

	fp = fopen("sfx\\EXPLODE.wav", "rb");
	fseek(fp, 0, SEEK_END);
	currentSize = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	EXPLODEBUFFER = malloc(currentSize);
	EXPLODESZ = currentSize;
	fread(EXPLODEBUFFER, 1, EXPLODESZ, fp);
	fclose(fp);

	fp = fopen("sfx\\LASER.wav", "rb");
	fseek(fp, 0, SEEK_END);
	currentSize = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	LASERBUFFER = malloc(currentSize);
	LASERSZ = currentSize;
	fread(LASERBUFFER, 1, LASERSZ, fp);
	fclose(fp);

	fp = fopen("sfx\\TNG.wav", "rb");
	fseek(fp, 0, SEEK_END);
	currentSize = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	TNGBUFFER = malloc(currentSize);
	TNGSZ = currentSize;
	fread(TNGBUFFER, 1, TNGSZ, fp);
	fclose(fp);

	fp = fopen("sfx\\TREK1.wav", "rb");
	fseek(fp, 0, SEEK_END);
	currentSize = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	TREK1BUFFER = malloc(currentSize);
	TREK1SZ = currentSize;
	fread(TREK1BUFFER, 1, TREK1SZ, fp);
	fclose(fp);

	fp = fopen("sfx\\TREK4.wav", "rb");
	fseek(fp, 0, SEEK_END);
	currentSize = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	TREK4BUFFER = malloc(currentSize);
	TREK4SZ = currentSize;
	fread(TREK4BUFFER, 1, TREK4SZ, fp);
	fclose(fp);

	fp = fopen("sfx\\TREK12.wav", "rb");
	fseek(fp, 0, SEEK_END);
	currentSize = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	TREK12BUFFER = malloc(currentSize);
	TREK12SZ = currentSize;
	fread(TREK12BUFFER, 1, TREK12SZ, fp);
	fclose(fp);

	fp = fopen("sfx\\TREK22.wav", "rb");
	fseek(fp, 0, SEEK_END);
	currentSize = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	TREK22BUFFER = malloc(currentSize);
	TREK22SZ = currentSize;
	fread(TREK22BUFFER, 1, TREK22SZ, fp);
	fclose(fp);
}

VOID initWaveHeader(WAVEHDR* wvHdr, char* lpData, DWORD dwBufferLength, DWORD dwBytesRecorded, DWORD_PTR dwUser, DWORD dwFlags, DWORD dwLoops){
    wvHdr->lpData = lpData;
    wvHdr->dwBufferLength = dwBufferLength;
    wvHdr->dwBytesRecorded = dwBytesRecorded;
    wvHdr->dwUser = dwUser;
    wvHdr->dwFlags = dwFlags;
    wvHdr->dwLoops = dwLoops;
}

void initWave(WAVEFORMATEX *wave, WORD wFormatTag, WORD nChannels, DWORD nSamplesPerSec, DWORD nAvgBytesPerSec, WORD nBlockAlign, WORD wBitsPerSample, WORD cbSize){
    wave->wFormatTag = wFormatTag;
    wave->nChannels = nChannels;
    wave->nSamplesPerSec = nSamplesPerSec;
    wave->nAvgBytesPerSec = nAvgBytesPerSec;
    wave->nBlockAlign = nBlockAlign;
    wave->wBitsPerSample = wBitsPerSample;
    wave->cbSize = cbSize;
}

void update_music(){
}

void stop_music(){
    //PlaySound(NULL, NULL, SND_ASYNC);
    //MessageBox(NULL, "Stopping music now", "Starblazer", MB_OK);
    stopMusicCalled = 1;
    waveOutBreakLoop(hWaveOut);
    waveOutReset(hWaveOut);
    waveOutPause(hWaveOut);

    if(waveOutClose(hWaveOut) != MMSYSERR_NOERROR){
        //MessageBox(NULL, "Die", "Starblazer", MB_OK);
    }
    waveOutClose(hWaveOut);
    free(sndBuffer);
    free(sndBackBuffer);

}

void __stdcall sndCallback(HWAVEOUT hwo, UINT msg, DWORD_PTR dwInstance, DWORD dwParam1, DWORD dwParam2){
    if(msg == WOM_DONE){
        if(stopMusicCalled){
            stopMusicCalled = 0;
        }
        else{
            PostMessage(hwnd, 0xEEEE, dwInstance, 0);
        }
    }
}

void init_music(char* file){
    FILE* fp;
    char name[40];
    int devs = waveOutGetNumDevs();
    sprintf(name, "%s.wav", file);

    //return;
    /*if(strcmp(file, "GAMEOVER") == 0){
        setting = SND_ASYNC;
    }

    PlaySound(name, NULL, setting);*/
    fp = fopen(name, "rb");
    fseek(fp, 0L, SEEK_END);
    sz = ftell(fp);
    fseek(fp, 0L, SEEK_SET);

    sndBuffer = malloc(sz);
    sndBackBuffer = malloc(sz);
    fread(sndBuffer, 1, sz, fp);
    memcpy(sndBackBuffer, sndBuffer, sz);
    initWaveHeader(&header, (char*)sndBuffer, sz, 0, 0, 0, 0);
    initWave(&wfx, WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0);

    if(devs){
        while(waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, &sndCallback, (DWORD_PTR)file, CALLBACK_FUNCTION) != MMSYSERR_NOERROR);
    }


    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));

    waveOutClose(hWaveOut);
    fclose(fp);

}

void init_music_no_callback(char* file){
    FILE* fp;
    char name[40];
    DWORD setting = SND_ASYNC | SND_LOOP;
    sprintf(name, "%s.wav", file);

    //return;
    /*if(strcmp(file, "GAMEOVER") == 0){
        setting = SND_ASYNC;
    }

    PlaySound(name, NULL, setting);*/
    fp = fopen(name, "rb");
    fseek(fp, 0L, SEEK_END);
    sz = ftell(fp) - 1000;
    fseek(fp, 0L, SEEK_SET);

    sndBuffer = malloc(sz);
    sndBackBuffer = malloc(sz);
    fread(sndBuffer, 1, sz, fp);
    memcpy(sndBackBuffer, sndBuffer, sz);
    initWaveHeader(&header, (char*)sndBuffer, sz, 0, 0, 0, 0);
    initWave(&wfx, WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0);
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));

    waveOutClose(hWaveOut);
    fclose(fp);

}

unsigned char* laserBuf;

#define sound_delay 2000

void play_soundfx(char* file){
    int sound_sz;
    FILE* fp;
    char name[40];
    MMTIME t;
    int i;
    DWORD setting = SND_ASYNC | SND_LOOP;
    //return;

    /*sprintf(name, "%s.wav", file);

    fp = fopen(name, "rb");					
    
    fseek(fp, 0L, SEEK_END);
								  
    sound_sz = ftell(fp);
    fseek(fp, 0L, SEEK_SET);

    laserBuf = malloc(sound_sz);
    fread(laserBuf, 1, sound_sz, fp);

    sprintf(name, "%d", sound_sz);*/
    
    if(strcmp(file, "sfx\\explode") == 0){
    	laserBuf = EXPLODEBUFFER;
		sound_sz = EXPLODESZ;
    } else if(strcmp(file, "sfx\\LASER") == 0){
    	laserBuf = LASERBUFFER;
		sound_sz = LASERSZ;
    } else if(strcmp(file, "sfx\\tng") == 0){
    	laserBuf = TNGBUFFER;
		sound_sz = TNGSZ;
    } else if(strcmp(file, "sfx\\trek1") == 0){
    	laserBuf = TREK1BUFFER;
		sound_sz = TREK1SZ;
    } else if(strcmp(file, "sfx\\trek4") == 0){
    	laserBuf = TREK4BUFFER;
		sound_sz = TREK4SZ;
    } else if(strcmp(file, "sfx\\trek12") == 0){
    	laserBuf = TREK12BUFFER;
		sound_sz = TREK12SZ;
    } else if(strcmp(file, "sfx\\trek22") == 0){
    	laserBuf = TREK22BUFFER;
		sound_sz = TREK22SZ;
    }		   

    t.wType = TIME_BYTES;

    if(waveOutGetPosition(hWaveOut, &t, sizeof(MMTIME)) != MMSYSERR_NOERROR){
        //fclose(fp);
        return;
    }

    for(i = 0; i < sound_sz - 1000; i++){
        //((unsigned char*)sndBuffer)[t.u.cb + sound_delay + i] = (unsigned short)( ((unsigned char*)sndBuffer)[t.u.cb + sound_delay + i] + laserBuf[i + 44] ) >> 1;//((char*)sndBuffer)[t.u.cb + 2000 + i];
        ((unsigned char*)sndBuffer)[t.u.cb + sound_delay + i] = (((unsigned char*)sndBackBuffer)[t.u.cb + sound_delay + i] + laserBuf[i+44] + ((unsigned char*)sndBuffer)[t.u.cb + sound_delay + i])/3;
    }

    //free(laserBuf);
	//fclose(fp);

    return;	   
}



	char curKey;




    LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam){
        PAINTSTRUCT ps;
        HDC hdc;
        HDC hdc_bmp;
        HDC test;
        HGDIOBJ old_bmp;
        HDRAWDIB hdd;

        switch(msg){

            case 0xEEEE:{

                stop_music();
                init_music(wParam);

                break;
            }

			case WM_KEYDOWN:{
				curKey = (char)wParam;
				break;
			}

			case WM_KEYUP:{
				curKey = 0;
				break;
			}

            case WM_CLOSE:{
                DestroyWindow(hWnd);
                ExitProcess(0);
                break;
            }

            case WM_DESTROY:{
                PostQuitMessage(0);
                break;
            }

            case WM_QUIT:{
                ExitProcess(0);
                break;
            }

            case WM_SIZE:{
                windowWidth = lParam & 0xffff;
                windowHeight = (lParam & 0xffff0000) >> 16;
                mouseFactorX = 320.0/windowWidth;
                mouseFactorY = 200.0/windowHeight;
                GetWindowRect(hWnd, &rectScreen);
                ClipCursor(&rectScreen);
                break;
            }


            case WM_LBUTTONDOWN:{
                GDK_mouse.b1 = 1;
                break;
            }

            case WM_LBUTTONUP:{
                GDK_mouse.b1 = 0;
                break;
            }

            case WM_RBUTTONDOWN:{
                GDK_mouse.b2 = 1;
                break;
            }

            case WM_RBUTTONUP:{
                GDK_mouse.b2 = 0;
                break;
            }

            case WM_PAINT:{
                #ifndef USE_DRAWDIB
                hdc = GetDC(hWnd);//BeginPaint(hWnd, &ps);

                #ifdef GDK_win32
                    hdc_bmp = CreateCompatibleDC(hdc);
                    old_bmp = SelectObject(hdc_bmp, backBitmap);
                    //BitBlt(hdc, 0, 0, globalWidth, globalHeight, hdc_bmp, 0, 0, SRCCOPY);
                    StretchBlt(hdc, 0, 0, windowWidth, windowHeight, hdc_bmp, 0, 0, globalWidth, globalHeight, SRCCOPY);
                    SelectObject(hdc, old_bmp);
                    DeleteDC(hdc_bmp);
                #else
                    StretchDIBits(hdc, 0, 0, windowWidth, windowHeight, 0, 0, globalWidth, globalHeight, backBits, &bmi, DIB_RGB_COLORS, SRCCOPY);
                    //SetDIBitsToDevice(hdc, 0, 0, globalWidth, globalHeight, 0, 0, 0, globalHeight, backBits, &bmi, DIB_RGB_COLORS);
                #endif

                #else
                GDK_drawBits();
                #endif

                //DrawDibDraw(hdd, hdc, 0, 0, windowWidth, windowHeight, (BITMAPINFOHEADER*)&bmi, backBits, 0, 0, globalWidth, globalHeight, DDF_SAME_HDC);

                //DrawDibClose(hdd);


                //memset(backBits, 0, globalHeight * globalWidth * globalBpp / 8);

                //EndPaint(hWnd, &ps);
                //break;
            }

            default:{
                return DefWindowProc(hWnd, msg, wParam, lParam);
            }

        }

    }


#endif

/**
    GDK_initialize
    Creates the graphic buffer to write into
**/

void GDK_initialize(int width, int height, int bpp, char* title){

    #ifdef GDK_win

        RECT winRect;
        FILE* fp;
        char file[100];

        HDC hdcScreen;

        fp = fopen("res.ini", "r");
        fscanf(fp, "%d %d", &windowWidth, &windowHeight);
        fclose(fp);

        winRect.left = 0;
        winRect.top = 0;
        winRect.bottom = windowHeight;
        winRect.right = windowWidth;

        mouseFactorX = 320.0/windowWidth;
        mouseFactorY = 200.0/windowHeight;

        AdjustWindowRect(&winRect, WS_OVERLAPPEDWINDOW, FALSE);

        bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        bmi.bmiHeader.biWidth = width;
        bmi.bmiHeader.biHeight = height; // top-down
        bmi.bmiHeader.biPlanes = 1;
        bmi.bmiHeader.biBitCount = bpp;
        bmi.bmiHeader.biCompression = BI_RGB;

        #ifdef GDK_win32
            hdcScreen = GetDC(NULL);
            backBitmap = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, (void**)(&backBits), NULL, NULL);
            ReleaseDC(NULL, hdcScreen);
        #endif

        if(joyGetPos(0, &joypos) == JOYERR_NOERROR){ //joystick attached

            joyUsed = 1;

            if(!(fp = fopen("joy.ini", "r"))){ //no calibration file, calibrating now
                system("joytest");
                fp = fopen("joy.ini", "r");
            }

            fscanf(fp, "%d %d %d %d %d %d", &centerX, &centerY, &topX, &topY, &bottomX, &bottomY);
            fclose(fp);
        }

        wc.style = 0;
        wc.lpfnWndProc = WndProc;
        wc.cbClsExtra = 0;
        wc.cbWndExtra = 0;
        wc.hInstance = hInstance_;
        wc.hIcon         = LoadIcon(hInstance_, MAKEINTRESOURCE(101));
        wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
        wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
        wc.lpszMenuName  = NULL;
        wc.lpszClassName = title;
        RegisterClass(&wc);

        //hwnd = CreateWindow(title, title, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, width + 16, height + 36, NULL, NULL, hInstance_, NULL);
        hwnd = CreateWindow(title, title, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, winRect.right - winRect.left, winRect.bottom - winRect.top, NULL, NULL, hInstance_, NULL);
        ShowWindow(hwnd, nCmdShow_);
        UpdateWindow(hwnd);

        GetWindowRect(hwnd, &rectScreen);

        if(!joyUsed){
            ClipCursor(&rectScreen);
        }
    #endif

    #ifndef GDK_win32
        backBits = malloc(width * height * bpp / 8);
    #endif

    globalWidth = width;
    globalHeight = height;
    globalBpp = bpp;

}


/**
    GDK_drawBits
    Waits for vertical refresh (if possible) and blits the passed buffer to the screen
**/

void GDK_drawBits(){
    #ifdef GDK_win
        #ifndef USE_DRAWDIB
        InvalidateRect(hwnd, NULL, 0);
        #else
        HDC hdc = GetDC(hwnd);
HDRAWDIB hdd = DrawDibOpen();
DrawDibDraw(hdd, hdc, 0, 0, windowWidth, windowHeight, (BITMAPINFOHEADER*)&bmi, backBits, 0, 0, globalWidth, globalHeight, DDF_SAME_HDC);
DrawDibClose(hdd);
TextOut(hdc, 160, 100, "Hello, world!", 10);
memset(backBits, 0, globalHeight * globalWidth * globalBpp / 8);
    #endif
    #endif
}


/**
    GDK_playWav
**/


/**
    GDK_update
**/

void GDK_update(){
    #ifdef GDK_win
        if(joyUsed){
            joyGetPos(0, &joypos);
            GDK_mouse.x = getX(joypos.wXpos);
            GDK_mouse.y = getY(joypos.wYpos);

            if(joypos.wButtons & JOY_BUTTON1){
                GDK_mouse.b1 = 1;
            }
            else{
                GDK_mouse.b1 = 0;
            }

            if(joypos.wButtons & JOY_BUTTON2){
                GDK_mouse.b2 = 1;
            }
            else{
                GDK_mouse.b2 = 0;
            }
        }
        else{
            GetCursorPos(&p);
            ScreenToClient(hwnd, &p);
            GDK_mouse.x = p.x * mouseFactorX;
            GDK_mouse.y = (p.y * mouseFactorY);
        }

        while(PeekMessage(&Msg, hwnd, 0, 0, PM_REMOVE)){
            TranslateMessage(&Msg);
            DispatchMessage(&Msg);
        }
    #endif
}


/**
    GDK_getMS
**/
