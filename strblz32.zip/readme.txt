STARBLAZER FOR WINDOWS BETA V1.0
--------------------------------
SYSTEM REQUIREMENTS
- Microsoft Windows 95 or greater / Microsoft Windows NT Version 3.51 or greater
- Intel Pentium processor or compatible 
- VGA-compatible graphics adapter in 16-bit color mode or higher
- 1MB of free storage
- 8MB of free memory (12+ recommended)

GAMEPLAY INSTRUCTIONS
Double click on strblz32.exe

THE GAME - THE SCENARIO
You are a Cleric in the United Space Missionary forces, attempting to spread the holy word across the galaxy to uncivilized cultures and planets. However,
the secular space empire has attacked. In attempting to mount a counterattack of their SSE-1 Battle Star, you, aboard your cutting-edge FX-1 Starfighter 
has become trapped in the Battle Star's trench to fight for your life!

THE OBJECTIVE
Stay alive as long as you can and blast every alien bastard that comes your way!

CONTACT INFORMATION
To voice your opinions on Starblazer or report any bugs, please email phasershow@gmail.com. If you are a lawyer, my email address is dontemailme@goaway.com