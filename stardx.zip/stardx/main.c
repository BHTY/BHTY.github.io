char* title = "Starblazer DX for Windows 95/NT";
#include "win.h"
#include <math.h>
#pragma comment (lib , "winmm.lib")

#define NUM_STARS 100
DX_VECTOR stars[NUM_STARS];	 
#define NUM_ENTITIES 1000 

int flash = 0;
char message[80];

void generate_star(DX_VECTOR* star){
	star->x = (rand() % 200) - 100;
	star->y = (rand() % 200) - 100;
	star->z = camera.z + (rand() % 200);
}

void tick_stars(char color){
	int i;
	int x, y;
	DX_VECTOR vec;

	for (i = 0; i < NUM_STARS; i++){
		vec.x = stars[i].x - camera.x;
		vec.y = stars[i].y - camera.y;
		vec.z = stars[i].z - camera.z;
									  	
		x = MulDiv(vec.x, xFOV, vec.z);
		y = MulDiv(vec.y, yFOV, vec.z);

		draw_pixel(back, 160 - x, 100 - y, color);

		if (stars[i].z < camera.z){
			generate_star(&stars[i]);			   
		}
	}
}

DX_OBJECT *bolt_obj;
DX_OBJECT *fx1_obj;	
DX_OBJECT *shard_obj;	
DX_ENTITY *entities[NUM_ENTITIES];

int firing = 0;
int cX = 160;
int cY = 100;
int score = 0;
int health = 48;

void shard_script(DX_ENTITY** entity_ptr){
	(*entity_ptr)->pos.y += (*entity_ptr)->state[2];
	(*entity_ptr)->pos.x += (*entity_ptr)->state[1];
	(*entity_ptr)->state[0]--;

	if((*entity_ptr)->pos.z <= camera.z || !(*entity_ptr)->state[0]){
		free(*entity_ptr);
		*entity_ptr = NULL;
	}
}

void bolt_script(DX_ENTITY** entity_ptr){
	(*entity_ptr)->pos.z-=2;

	if ( ((*entity_ptr)->pos.z - camera.z) <= 2){
		if ( ( abs((*entity_ptr)->pos.x - camera.x) < 20 ) && (abs((*entity_ptr)->pos.y - camera.y) < 16) ){
			printf("Incoming hit!\n");
			free(*entity_ptr);
			*entity_ptr = NULL;

			flash = 2;
			setPalIndex(0, 255, 128, 0);
			health -= 8;
		}
	}
}

void fx1_script(DX_ENTITY** entity_ptr){
	int i;
	int shards = 64;

	int z = ((*entity_ptr)->pos.z - camera.z);
	int xSize = 40 * 100 / z;
	int ySize = 20 * 100 / z;
	int centerX = 160 - MulDiv((*entity_ptr)->pos.x - camera.x, xFOV, z);
	int centerY = 100 - MulDiv((*entity_ptr)->pos.y - camera.y, yFOV, z);	

	/*
	drawline(centerX - xSize, centerY - ySize, centerX + xSize, centerY - ySize, 44);
	drawline(centerX + xSize, centerY + ySize, centerX + xSize, centerY - ySize, 44);
	drawline(centerX - xSize, centerY - ySize, centerX - xSize, centerY + ySize, 44);
	drawline(centerX - xSize, centerY + ySize, centerX + xSize, centerY + ySize, 44);
	*/

	if(firing){
		if( (cX <= centerX + xSize) && (cX >= centerX - xSize) && (cY <= centerY + ySize) && (cY >= centerY - ySize)){
			printf("Direct hit!\n"); 
			score++;

			for(i = 0; i < NUM_ENTITIES; i++){
				if(!entities[i]){
					entities[i] = malloc(sizeof(DX_ENTITY));
					entities[i]->pos.x = (*entity_ptr)->pos.x + rand() % 20 - 10;		 
					entities[i]->pos.y = (*entity_ptr)->pos.y + rand() % 20 - 10;
					entities[i]->pos.z = (*entity_ptr)->pos.z;	  
					entities[i]->obj = shard_obj;
					entities[i]->state[0] = 105;
					entities[i]->state[1] = rand() % 20 - 10;
					entities[i]->state[2] = rand() % 20 - 10;
					shards--;
				}

				if(!shards){break;}
			}

			free(*entity_ptr);
			*entity_ptr = NULL;

			return;
		}
	}

	if((*entity_ptr)->state[0]){
		(*entity_ptr)->state[0]--;
	}
	else{
		for(i = 0; i < NUM_ENTITIES; i++){
			if(!entities[i]){
				entities[i] = malloc(sizeof(DX_ENTITY));
				entities[i]->obj = bolt_obj;
				entities[i]->pos = (*entity_ptr)->pos;
				printf("Bolt fired!\n");
				break;
			}						   
		}

		(*entity_ptr)->state[0] = 70;
	}
}



void title_screen(){
	int i;
	
	for(i = 0; i < NUM_STARS; i++){
		generate_star(&stars[i]);
	}

	while(1){
		tick_stars(0x0F);
		camera.z++;
		DX_PRESENT(1);
		DX_UPDATE();
		DX_WAITBLANK();

		if(keys['J']){
			break;
		}
	}

	for(i = 140; i >= 0; i--){
		tick_stars(0x0F);
		camera.z++;
		DX_PRESENT(0);
		DX_UPDATE();
		DX_WAITBLANK();
	} 

	DX_PRESENT(1);
}

						 
#define ENEMY_TIMEOUT (38 + rand() % 24)

int main(){	
	int enemy_spawn_countdown;	   
	int laser_charge = 48;
	int discharged = 0;

	FILE* fp = fopen("dat.bin", "rb");
	char* numbers = malloc(2496);
	 
	char laserPosition = 0;
	
	int i;				 
	//DX_ENTITY *entity = malloc(sizeof(DX_ENTITY));
	entities[0] = malloc(sizeof(DX_ENTITY));

	fread(numbers, 1, 2496, fp);
	fclose(fp);

	hInstance_ = GetModuleHandle(NULL);
	srand(time(NULL));
	DX_CREATEWINDOW(1024, 768);

	setPalIndex(51, 0, 255, 255);
	setPalIndex(31, 255, 255, 255);
	setPalIndex(36, 255, 0, 255);
	setPalIndex(44, 255, 255, 0);
	setPalIndex(52, 0, 255, 255);
	setPalIndex(48, 0, 255, 0);
	setPalIndex(1, 0, 0, 255);
	setPalIndex(40, 255, 0, 0);
	setPalIndex(15, 255, 255, 255);
	setPalIndex(12, 255, 0, 0);
	setPalIndex(42, 255, 128, 0);

	enemy_spawn_countdown = ENEMY_TIMEOUT;

	DX_SETTIMER();

	title_screen();

	camera.z = 0;

	for(i = 0; i < NUM_STARS; i++){
		generate_star(&stars[i]);
	}

	bolt_obj = DX_LOADOBJECT("bolt.obj", bolt_script);
	fx1_obj = DX_LOADOBJECT("fx1.obj", fx1_script);
	shard_obj = DX_LOADOBJECT("shard.obj", shard_script);
	entities[0]->obj = fx1_obj;
	entities[0]->pos.x = 0;
	entities[0]->pos.y = 0;
	entities[0]->pos.z = camera.z + 400;

	while(1){
		tick_stars(0x0F);		  
		camera.z++;					   

		drawline(0, 35, 10, 35, 0x28); //top-left
        drawline(0, 65, 10, 65, 0x28);
        drawline(10, 35, 10, 65, 0x28);
        drawline(10, 45, 20, 45, 0x28);
        drawline(10, 55, 20, 55, 0x28);
        drawline(20, 45, 20, 55, 0x28);
        drawline(20, 50, 30, 50, 0x28);

        drawline(0, 135, 10, 135, 0x28); //bottom-left
	    drawline(0, 165, 10, 165, 0x28);
	    drawline(10, 135, 10, 165, 0x28);
        drawline(10, 145, 20, 145, 0x28);
        drawline(10, 155, 20, 155, 0x28);
        drawline(20, 145, 20, 155, 0x28);
        drawline(20, 150, 30, 150, 0x28);

        drawline(319, 35, 309, 35, 0x28); //top-right
        drawline(319, 65, 309, 65, 0x28);
        drawline(309, 35, 309, 65, 0x28);
        drawline(309, 45, 299, 45, 0x28);
        drawline(309, 55, 299, 55, 0x28);
        drawline(299, 45, 299, 55, 0x28);
        drawline(299, 50, 289, 50, 0x28);

        drawline(319, 135, 309, 135, 0x28); //bottom-right
        drawline(319, 165, 309, 165, 0x28);
        drawline(309, 135, 309, 165, 0x28);
        drawline(309, 145, 299, 145, 0x28);
        drawline(309, 155, 299, 155, 0x28);
        drawline(299, 145, 299, 155, 0x28);
        drawline(299, 150, 289, 150, 0x28);


		//draw health bar
		drawline(5, 75, 15, 75, 31);
		drawline(5, 125, 15, 125, 31);
		drawline(5, 75, 5, 125, 31);
		drawline(15, 75, 15, 125, 31);

		for(i = 76; i <= (76 + health); i++){
			drawline(6, i, 15, i, 1);
		}

		//draw laser bar
		drawline(315, 75, 305, 75, 31);
		drawline(315, 125, 305, 125, 31);
		drawline(315, 75, 315, 125, 31);
		drawline(305, 75, 305, 125, 31);

		for(i = 76; i <= (76 + laser_charge); i++){
			drawline(306, i, 315, i, 0x24);
		}


		//draw targeting reticle
		drawline(cX - 10, cY - 10, cX - 10, cY + 10, 48);
        drawline(cX + 10, cY - 10, cX + 10, cY + 10, 48);

        drawline(cX - 10, cY - 10, cX - 5, cY - 10, 48);
        drawline(cX + 10, cY - 10, cX + 5, cY - 10, 48);

        drawline(cX - 10, cY + 10, cX - 5, cY + 10, 48);
        drawline(cX + 10, cY + 10, cX + 5, cY + 10, 48);

		draw_pixel(back, cX, cY, 48);

		//drawline(cX - 5, cY - 5, cX + 5, cY + 5, 48);
		//drawline(cX - 5, cY + 5, cX + 5, cY - 5, 48);

		if(keys['W']){
			camera.y++;
			cY--;
		}
		else{
			if(cY<100){cY++;}
		}

		if(keys['S']){
			camera.y--;
			cY++;
		}
		else{
			if(cY>100){cY--;}
		}

		if(keys['A']){
			camera.x++;
			cX--;
		}
		else{
			if(cX<160){cX++;}
		}

		if(keys['D']){
			camera.x--;
			cX++;
		}
		else{  
			if(cX>160){cX--;}
		}

		if(keys['J']){
			firing = !discharged;
																																																											 
		}
		else{
			firing = 0;
		}

		
		if(firing){
			if (laserPosition) {		   
				drawline(30, 50, cX, cY, 51);
				drawline(290, 50, cX, cY, 51);
			}
			else{
				drawline(30, 150, cX, cY, 51);
				drawline(290, 150, cX, cY, 51);
			}

			laserPosition = !laserPosition;
			
			laser_charge--;
			if(laser_charge == 0){
				discharged = 1;
			}
		}
		else{
			if(laser_charge < 48){
				laser_charge++;
			}

			if(laser_charge >= 24){
				discharged = 0;
			}
		}


 		for(i = 0; i < NUM_ENTITIES; i++){  	  
			if(entities[i]){
				if(entities[i]->pos.z <= camera.z){
					free(entities[i]);
					continue;
				}

				DX_DRAWENTITY(entities[i]);	  
				entities[i]->obj->callback(&entities[i]);
			}
		}

		if(!enemy_spawn_countdown){
			for(i = 0; i < NUM_ENTITIES; i++){
				if(!entities[i]){
					entities[i] = malloc(sizeof(DX_ENTITY));
					entities[i]->obj = fx1_obj;
					entities[i]->pos.x = rand() % 400 - 200;
					entities[i]->pos.y = rand() % 400 - 200;
					entities[i]->pos.z = camera.z + 450 + (rand() % 200);
					break;
				}
			}

			enemy_spawn_countdown = ENEMY_TIMEOUT;
			printf("New entity spawned!\n");
		}
		else{
			enemy_spawn_countdown--;
		}

						  
		blitmap(numbers + 64 * ((score % 10000)/1000), 136+0, 0, 8, 8);
		blitmap(numbers + 64 * ((score % 1000)/100), 136+8, 0, 8, 8);
 		blitmap(numbers + 64 * ((score % 100)/10), 136+16, 0, 8, 8);
		blitmap(numbers + 64 * (score % 10), 136+24, 0, 8, 8);

 		blitmap(numbers, 136+32, 0, 8, 8);
		blitmap(numbers, 136+40, 0, 8, 8);


		DX_PRESENT(1);
		DX_UPDATE();
		DX_WAITBLANK();
		
		if(flash){
			flash--;
		}
		if(!flash){
			setPalIndex(0, 0, 0, 0);
		}
		
		if(health <= 0){
			sprintf(message, "GAME OVER! You've been Starblazed!\nYour score was: %d00", score);
			MessageBoxA(hwnd, message, "STARBLAZER: 2000 A.D.", MB_OK);
			ExitProcess(0);
		}					
	}
}
