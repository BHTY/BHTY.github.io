void drawline(int x, int y, int x2, int y2, unsigned char color) {
    int j, decInc;
    int i;
    char *address;
	char* backbuffer = back;
    int addrInc;

        int yLonger=0;
        int incrementVal, endVal;
	
        int shortLen;
        int longLen;
        if ((x < 0 || y < 0 || x > 319 || y > 199) && (x2 < 0 || y2 < 0 || x2 > 319 || y2 > 199)) return;
        if (x2 < 0) {
        	//y2 = 0;
		y2 = y - ((y2 - y)*x) / (x2 - x);
		x2 = 0;
	}
	if (x < 0) {
		//y = 0;
		y = y2 - ((y - y2)*x2) / (x - x2);
		x = 0;
	}
	
        if (x2 > 319) {
        	//y2 = 0;
		y2 = y + ((y2 - y)*(320 - x)) / (x2 - x);
		x2 = 319;
	}
	if (x > 319) {
		//y = 0;
		y = y2 + ((y - y2)*(320 - x2)) / (x - x2);
		x = 319;
	}
	
	if (y2 < 0) {
        	//y2 = 0;
		x2 = x - ((x2 - x)*y) / (y2 - y);
		y2 = 0;
	}
	if (y < 0) {
		//y = 0;
		x = x2 - ((x - x2)*y2) / (y - y2);
		y = 0;
	}
	
        if (y2 > 199) {
        	//y2 = 0;
		x2 = x + ((x2 - x)*(200 - y)) / (y2 - y);
		y2 = 199;
	}
	if (y > 199) {
		//y = 0;
		x = x2 + ((x - x2)*(200 - y2)) / (y - y2);
		y = 199;
	}
        //if (x == 160 || y == 100 || x2 == 160 || y2 == 100) return;
	shortLen = y2-y;
	longLen = x2-x;
        if (abs(shortLen)>abs(longLen)) {
                int swap=shortLen;
                shortLen=longLen;
                longLen=swap;
                yLonger=1;
        }
        endVal=longLen;
        if (longLen<0) {
                incrementVal=-1;
                addrInc=-320;
                longLen=-longLen;
        } else{incrementVal=1;
            addrInc = 320;
        }
        if (longLen==0) decInc=0;
        else decInc = (shortLen << 16) / longLen;
        j=0;
            address = backbuffer + (x) + (y)*320;

        if (yLonger) {

                for (i=0;i!=endVal;i+=incrementVal,address+=addrInc) {
                        //draw_pixel(x+(j >> 16),y+i, color);
                        *(address+(j>>16)) = color;

                        j+=decInc;
                }
        } else {
                for (i=0;i!=endVal;i+=incrementVal,address+=incrementVal) {
                        *(address+(j>>16)*320) = color;
                        //*(address+(j>>10)+(j>>8)) = color;
                        //draw_pixel(x+i,y+(j >> 16), color);
                        j+=decInc;
                }
        }


}