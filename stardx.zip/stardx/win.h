#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <mmsystem.h>
#include <stdlib.h>

char* back;
#include "drawing.h"
		


BOOL keys[256];

						 
int xFOV = 0x64;
int yFOV = 0x64;

int newFrame = 1;
char* backBits;
int globalHeight;
int globalWidth;
int globalBpp;
int windowWidth;
int windowHeight;
float mouseFactorX, mouseFactorY;
BITMAPINFO *bmi;
RECT rectScreen;
HBITMAP backBitmap;

 HPALETTE hPalette;
    POINT p;

    //GDK_mouseStatus GDK_mouse;

    HWND hwnd;
    WNDCLASS wc;
    MSG Msg;

    HINSTANCE hInstance_;
    int nCmdShow_ = 0;

typedef struct DX_VECTOR{
	int x, y, z;
} DX_VECTOR;


DX_VECTOR camera = {0};

typedef struct DX_LINE{
	char p1;
	char p2;
	char color;
} DX_LINE;

typedef struct DX_OBJECT{
	DX_VECTOR *points;
	DX_LINE *lines;
	int numLines;
	int numPoints;
	int size;
	void (*callback)(struct DX_ENTITY**);
} DX_OBJECT;

typedef struct DX_ENTITY{
	DX_OBJECT* obj;
	DX_VECTOR pos;
	int state[8];
} DX_ENTITY;

DX_VECTOR cache[100];	 

void DX_DRAWENTITY(DX_ENTITY* entity){
	int i;
	int x;
	int y;
	int z;

	DX_OBJECT *obj = entity->obj;

	for(i = 0; i < obj->numPoints; i++){
		x = entity->pos.x + obj->points[i].x - camera.x;
		y = entity->pos.y + obj->points[i].y - camera.y;
		z = entity->pos.z + obj->points[i].z - camera.z;

		//printf("Z: %d\n", z);

		cache[i].x = MulDiv(x, xFOV, z);
		cache[i].y = MulDiv(y, yFOV, z);
	}

	for(i = 0; i < obj->numLines; i++){
		drawline(160 - cache[obj->lines[i].p1].x, 100 - cache[obj->lines[i].p1].y, 160 - cache[obj->lines[i].p2].x, 100 - cache[obj->lines[i].p2].y, obj->lines[i].color);
	}
}


DX_OBJECT* DX_LOADOBJECT(char* filename, void (*callback)(struct DX_ENTITY**)){
	FILE* fp = fopen(filename, "r");
	DX_OBJECT *obj = malloc(sizeof(DX_OBJECT));			   
	char lineHeader[8];

	int curShade;
	int p1;
	int p2;
	int res;
	int curPt = 0;										   
	int curLine = 0;
	int eof = 0;
							 
	obj->callback = callback;

	while(!eof){
		res = fscanf(fp, "%s", lineHeader);
		if(res == -1){eof = 1; break;}

		if(strcmp(lineHeader, "size") == 0){
			fscanf(fp, "%d\n", &(obj->size));
		}

		if(strcmp(lineHeader, "lines") == 0){
			fscanf(fp, "%d\n", &(obj->numLines));
			obj->lines = malloc(obj->numLines * sizeof(DX_LINE));
		}
		if(strcmp(lineHeader, "points") == 0){
			fscanf(fp, "%d\n", &(obj->numPoints));
			obj->points = malloc(obj->numPoints * sizeof(DX_VECTOR));
		}
		if(strcmp(lineHeader, "p") == 0){
			fscanf(fp, "%d %d\n", &(obj->points[curPt].x), &(obj->points[curPt].y));
			curPt++;
		}
		if(strcmp(lineHeader, "v") == 0){
			fscanf(fp, "%d %d %d\n", &p1, &p2, &curShade);
			obj->lines[curLine].p1 = p1;
			obj->lines[curLine].p2 = p2;
			obj->lines[curLine].color = curShade;
			curLine++;
		}
	}

	fclose(fp);

	printf("Loaded object %s\n", filename);


	return obj;
}


void __stdcall mmproc(unsigned int uTimerID, unsigned int uMsg, unsigned int* dwUser, unsigned int* dw, unsigned int* dw2){
	newFrame = 1;
}

void DX_SETTIMER(){	   
	timeSetEvent(14, 1, (LPTIMECALLBACK)&mmproc, 0, TIME_CALLBACK_FUNCTION | TIME_PERIODIC);
}

void draw_pixel(char* backbuffer, int x, int y, char c){
        if (x >= 0 && x < 320 && y >= 0 && y < 200){
                backbuffer[y * 320 + x] = c;
                //backbuffer[(y<<6) + (y<<8) + x] = c;
        }
}

void blitmap(char* pixels, short x, short y, short lengthX, short lengthY) {
        int i, o;
        for (i = 0; i < lengthY; i++) {
                for (o = 0; o < lengthX; o++) {
                        if (pixels[lengthX * i + o]) {
                                draw_pixel(back, x + o, y + i, 48);
                        }
                }
        }
}

void DX_UPDATE(){
	while(PeekMessage(&Msg, hwnd, 0, 0, PM_REMOVE)){
            TranslateMessage(&Msg);
            DispatchMessage(&Msg);
        }
}

void DX_WAITBLANK(){
	while(!newFrame){
		DX_UPDATE();
	}																					   

	newFrame = 0;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam){
	PAINTSTRUCT ps;
        HDC hdc;
        HDC hdc_bmp;
        HDC test;
        HGDIOBJ old_bmp;

	switch(msg){
		case WM_CLOSE:{
                DestroyWindow(hWnd);
                ExitProcess(0);
                break;
        }

        case WM_DESTROY:{
                PostQuitMessage(0);
                break;
        }

        case WM_QUIT:{
                ExitProcess(0);
                break;
        }

		case WM_KEYDOWN:{
			keys[(unsigned char)wParam] = 1;
			break;
		}

		case WM_KEYUP:{
			keys[(unsigned char)wParam] = 0;
			break;
		}

		case WM_PAINT:{
			hdc = GetDC(hWnd);
			hdc_bmp = CreateCompatibleDC(hdc);
			old_bmp = SelectObject(hdc_bmp, backBitmap);
			StretchBlt(hdc, 0, 0, windowWidth, windowHeight, hdc_bmp, 0, 0, globalWidth, globalHeight, SRCCOPY);
			SelectObject(hdc, old_bmp);
			DeleteDC(hdc_bmp);
		}


		default:{
			return DefWindowProc(hWnd, msg, wParam, lParam);
		}
	}
}


void DX_CREATEWINDOW(int width, int height){
	RECT winRect;
	HDC hdcScreen;

	winRect.left = 0;
	winRect.top = 0;
	winRect.bottom = height;
	winRect.right = width;

	mouseFactorX = 320.0/width;
	mouseFactorY = 200.0/height;

	AdjustWindowRect(&winRect, WS_OVERLAPPEDWINDOW, FALSE);

	bmi = malloc(sizeof(BITMAPINFO) + 256 * sizeof(RGBQUAD));

	bmi->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi->bmiHeader.biWidth = 320;
	bmi->bmiHeader.biHeight = -200;
	bmi->bmiHeader.biPlanes = 1;
	bmi->bmiHeader.biBitCount = 8;
	bmi->bmiHeader.biClrUsed = 256;
	bmi->bmiHeader.biCompression = BI_RGB;

	hdcScreen = GetDC(NULL);
	backBitmap = CreateDIBSection(hdcScreen, bmi, DIB_RGB_COLORS, (void**)(&backBits), NULL, NULL);
	ReleaseDC(NULL, hdcScreen);

	wc.style = 0;
	wc.lpfnWndProc = WndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance_;
    wc.hIcon         = LoadIcon(hInstance_, MAKEINTRESOURCE(101));
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
    wc.lpszMenuName  = NULL;
    wc.lpszClassName = title;
    RegisterClass(&wc);

	globalWidth = 320;
	globalHeight = 200;
	windowWidth = width;
	windowHeight = height;
	globalBpp = 8;
							   
	hwnd = CreateWindow(title, title, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, winRect.right - winRect.left, winRect.bottom - winRect.top, NULL, NULL, hInstance_, NULL);
    ShowWindow(hwnd, SW_SHOW);
    UpdateWindow(hwnd);

    GetWindowRect(hwnd, &rectScreen);

	//ClipCursor(&rectScreen);
	back = malloc(64000);							   
}

void DX_PRESENT(int clr){
	memcpy(backBits, back, 64000);
	if(clr){memset(back, 0, 64000);}
	InvalidateRect(hwnd, NULL, 0);
}

void setPalIndex(unsigned int index, unsigned char R, unsigned char G, unsigned char B){
	RGBQUAD col;
	RGBQUAD *willPalette = &(bmi->bmiColors[0]);

	HDC tempHdc = CreateCompatibleDC(NULL);
	SelectObject(tempHdc, backBitmap);
	col.rgbRed = R;
	col.rgbGreen = G;
	col.rgbBlue = B;
	willPalette[index] = col;

	SetDIBColorTable(tempHdc, index, 1, willPalette + index);
	DeleteDC(tempHdc);
}
