STARBLAZER DX BY WILL KLEES
"CAPTAIN WILL STARBLAZER"
March 26, 2023
---------------------------
This is Starblazer DX Beta v0.5, as submitted for the BlairHacks competition in 2023. Intended to be a remake of the original Starblazer: 2000 A.D., all of the code was written from scratch and within the time of the competition, though some art was carried over from the original.

No frameworks or libraries were used, all of the code was written directly in C for the Win32 API. It supports Windows 95/NT or above on any x86-based computer.

Press the WASD keys to move and the J key to fire. Try to dodge all enemy blasts and take out as many enemies as possible! Good luck, soldier!