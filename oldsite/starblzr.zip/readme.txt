STARBLAZER II FOR WINDOWS 95/NT RELEASE NOTES
---------------------------------------------
SERVER SETUP INSTRUCTIONS
Before running server.exe, set the two ports in svrcfg.ini to be UDP ports that are unblocked by your PC's firewall (or make an exception). If you wish to run over the internet and not merely over a LAN, ensure that the ports are unblocked by your router firewall (or make an exception) and port-forward them to your machine. Then, execute server.exe and your computer will host a server.

CLIENT SETUP INSTRUCTIONS
Before launching the game (see the list below for the appropriate executable for your machine), there are settings in clientcfg.ini that must be set correctly. Set the default resolution under the width and height fields, and type the IP address of the server you're connecting to under the serverip field. Note that if you are connecting to a server that is on the same LAN as your computer, connect using its local IP address and not its public IP address. If the ports used by the server are blocked by your PC or router firewall, make an exception, and if you intend to play over the internet, ensure that portcts and portstc are forwarded to your machine.

If you wish to use a joystick, first run joytest.exe to calibrate your joystick (the settings will persist after detaching and reattaching your joystick, but must be recalibrated each time you connect a new joystick), and then execute the game with a joystick attached.

ARCHITECTURE / EXECUTABLE LIST
Executable image name        Target architecture    Minimum operating system                        Compiler used
STARBLZR.EXE                 Intel x86 32-bit       Windows 95 / Windows NT 3.50                    Visual C++ 2.0
STARMIPS.EXE                 MIPS R4000             Windows NT 3.50                                 Visual C++ 2.0
STARAXP.EXE                  DEC Alpha AXP          Windows NT 3.51                                 Visual C++ 6.0
STARPPC.EXE                  IBM PowerPC 60x        Windows NT 3.51                                 Visual C++ 4.1
STARIA64.EXE                 Intel Itanium          Windows XP (5.1) 64-bit Edition Version 2002    Windows XP SDK (VC7)
STARBL64.EXE                 AMD64/EM64T/IA-32e     Windows XP (5.2) Professional x64 Edition       Windows Server 2003 DDK (VC8)
Please note that the Win32s environment for Windows 3.1 is not a supported configuration. Windows NT 3.1 is also not supported.