/**
    GRAPHICS.H
    This header file contains key functions for VGA hardware control and graphics output.
**/

#define _textmode 0x03
#define _graphicsmode 0x13

char *title = "Starblazer II for Windows 95/NT";
MSG Msg;
RECT rectScreen;
WNDCLASS wc;

JOYINFO joypos;
int joyUsed = 0;

int window_width;
int window_height;

unsigned long centerX, centerY, topX, topY, bottomX, bottomY;

int getX(int rawX){
    if(rawX > centerX){
        return 160 + 160 * (float)(rawX - centerX)/(topX - centerX);
    }else if(rawX < centerX){
        return 160 - 160 * (float)(centerX - rawX)/(centerX - bottomX);
    }
    return 160;
}

int getY(int rawY){
    if(rawY > centerY){
        return 100 + 100 * (float)(rawY - centerY)/(topY - centerY);
    }else if(rawY < centerY){
        return 100 - 100 * (float)(centerY - rawY)/(centerY - bottomY);
    }
    return 100;
}

unsigned char keys[256] = {0};

int globalHeight;
int globalWidth;
int globalBpp;
int windowWidth;
int windowHeight;

HINSTANCE hInstance_;
int nCmdShow_ = 0;

char* VGA;
char* backbuffer;
int newFrame = 1;

BITMAPINFO *bmi;
HBITMAP backBitmap;
HPALETTE hPalette;
HWND hwnd;

void __stdcall mmproc(unsigned int uTimerID, unsigned int uMsg, unsigned int* dwUser, unsigned int* dw, unsigned int* dw2){
	newFrame = 1;
}

void DX_SETTIMER(){	   
	timeSetEvent(14, 1, (LPTIMECALLBACK)&mmproc, 0, TIME_CALLBACK_FUNCTION | TIME_PERIODIC);
}

typedef struct{
	char* data;
	int bytes;
} snd_cache;

WAVEFORMATEX wfx;
HWAVEOUT hWaveOut = 0;
void* sndBuffer;
void* sndBackBuffer;
MMTIME t;
WAVEHDR header;
int sz;
int stopMusicCalled = 0;

snd_cache hit_sfx;
snd_cache laser_sfx;
snd_cache explode_sfx;

snd_cache cache_sound(char* filename){
	snd_cache cache;
	FILE* fp = fopen(filename, "rb");
	fseek(fp, 0, SEEK_END);
	cache.bytes = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	cache.data = malloc(cache.bytes);
	fread(cache.data, 1, cache.bytes, fp);
	fclose(fp);
	
	return cache;
}

void init_cache(){
	hit_sfx = cache_sound("sfx\\hit.wav");
	explode_sfx = cache_sound("sfx\\explode.wav");
	laser_sfx = cache_sound("sfx\\laser.wav");
}

void stop_music(){
    //PlaySound(NULL, NULL, SND_ASYNC);
    //MessageBox(NULL, "Stopping music now", "Starblazer", MB_OK);
    stopMusicCalled = 1;
    waveOutBreakLoop(hWaveOut);
    waveOutReset(hWaveOut);
    waveOutPause(hWaveOut);

    if(waveOutClose(hWaveOut) != MMSYSERR_NOERROR){
        //MessageBox(NULL, "Die", "Starblazer", MB_OK);
    }
    waveOutClose(hWaveOut);
    free(sndBuffer);
    free(sndBackBuffer);

}

void __stdcall sndCallback(HWAVEOUT hwo, UINT msg, DWORD* dwInstance, DWORD dwParam1, DWORD dwParam2){
    if(msg == WOM_DONE){
        if(stopMusicCalled){
            stopMusicCalled = 0;
        }
        else{
            PostMessage(hwnd, 0xEEEE, dwInstance, 0);
        }
    }
}


VOID initWaveHeader(WAVEHDR* wvHdr, char* lpData, DWORD dwBufferLength, DWORD dwBytesRecorded, DWORD* dwUser, DWORD dwFlags, DWORD dwLoops){
    wvHdr->lpData = lpData;
    wvHdr->dwBufferLength = dwBufferLength;
    wvHdr->dwBytesRecorded = dwBytesRecorded;
    wvHdr->dwUser = dwUser;
    wvHdr->dwFlags = dwFlags;
    wvHdr->dwLoops = dwLoops;
}

void initWave(WAVEFORMATEX *wave, WORD wFormatTag, WORD nChannels, DWORD nSamplesPerSec, DWORD nAvgBytesPerSec, WORD nBlockAlign, WORD wBitsPerSample, WORD cbSize){
    wave->wFormatTag = wFormatTag;
    wave->nChannels = nChannels;
    wave->nSamplesPerSec = nSamplesPerSec;
    wave->nAvgBytesPerSec = nAvgBytesPerSec;
    wave->nBlockAlign = nBlockAlign;
    wave->wBitsPerSample = wBitsPerSample;
    wave->cbSize = cbSize;
}

void init_music(char* file){
    FILE* fp;
    char name[40];
    int devs = waveOutGetNumDevs();
    sprintf(name, "%s", file);

    //return;
    /*if(strcmp(file, "GAMEOVER") == 0){
        setting = SND_ASYNC;
    }

    PlaySound(name, NULL, setting);*/
    fp = fopen(name, "rb");
    fseek(fp, 0L, SEEK_END);
    sz = ftell(fp);
    fseek(fp, 0L, SEEK_SET);

    sndBuffer = malloc(sz);
    sndBackBuffer = malloc(sz);
    fread(sndBuffer, 1, sz, fp);
    memcpy(sndBackBuffer, sndBuffer, sz);
    initWaveHeader(&header, (char*)sndBuffer, sz, 0, 0, 0, 0);
    initWave(&wfx, WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0);

    if(devs){
        while(waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, &sndCallback, (DWORD*)file, CALLBACK_FUNCTION) != MMSYSERR_NOERROR);
    }


    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));

    waveOutClose(hWaveOut);
    fclose(fp);

}

#define sound_delay 2000
unsigned char * laserBuf;

void play_soundfx(char* file){
    int sound_sz;
    FILE* fp;
    char name[40];
    MMTIME t;
    int i;
    DWORD setting = SND_ASYNC | SND_LOOP;
    
    if(strcmp(file, "sfx\\explode.wav") == 0){
    	laserBuf = explode_sfx.data;
		sound_sz = explode_sfx.bytes;
    } else if(strcmp(file, "sfx\\laser.wav") == 0){
    	laserBuf = laser_sfx.data;
		sound_sz = laser_sfx.bytes;
    } else if(strcmp(file, "sfx\\hit.wav") == 0){
    	laserBuf = hit_sfx.data;
		sound_sz = hit_sfx.bytes;
    }		   

    t.wType = TIME_BYTES;

    if(waveOutGetPosition(hWaveOut, &t, sizeof(MMTIME)) != MMSYSERR_NOERROR){
        //fclose(fp);
        return;
    }

    for(i = 0; i < sound_sz - 1000; i++){
        //((unsigned char*)sndBuffer)[t.u.cb + sound_delay + i] = (unsigned short)( ((unsigned char*)sndBuffer)[t.u.cb + sound_delay + i] + laserBuf[i + 44] ) >> 1;//((char*)sndBuffer)[t.u.cb + 2000 + i];
        ((unsigned char*)sndBuffer)[t.u.cb + sound_delay + i] = (((unsigned char*)sndBackBuffer)[t.u.cb + sound_delay + i] + laserBuf[i+44] + ((unsigned char*)sndBuffer)[t.u.cb + sound_delay + i])/3;
    }

    //free(laserBuf);
	//fclose(fp);

    return;	   
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam){
	HDC hdc;
	HDC hdc_bmp;
	HGDIOBJ old_bmp;

	switch(msg){
		case 0xEEEE:{
			stop_music();
			init_music(wParam);
			break;
					}

		case WM_CLOSE:{
                DestroyWindow(hWnd);
                ExitProcess(0);
                break;
        }

        case WM_DESTROY:{
                PostQuitMessage(0);
                break;
        }

        case WM_QUIT:{
                ExitProcess(0);
                break;
        }

		case WM_KEYDOWN:{
			keys[(unsigned char)wParam] = 1;
			break;
		}

		case WM_KEYUP:{
			keys[(unsigned char)wParam] = 0;
			break;
		}

		case WM_SIZE:{
			windowWidth = lParam & 0xffff;
			windowHeight = (lParam & 0xffff0000) >> 16;
			break;			 
		}

		case WM_PAINT:{
			hdc = GetDC(hWnd);
			hdc_bmp = CreateCompatibleDC(hdc);
			old_bmp = SelectObject(hdc_bmp, backBitmap);
			StretchBlt(hdc, 0, 0, windowWidth, windowHeight, hdc_bmp, 0, 0, globalWidth, globalHeight, SRCCOPY);
			SelectObject(hdc, old_bmp);
			DeleteDC(hdc_bmp);
		}

		default:{
			return DefWindowProc(hWnd, msg, wParam, lParam);
		}
	}
}

void setmode(char mode){ //sets the VGA card to the given display mode
    RECT winRect;
	HDC hdcScreen;
	FILE *fp;

	int width = window_width;
	int height = window_height;

	winRect.left = 0;
	winRect.top = 0;
	winRect.bottom = height;
	winRect.right = width;

	AdjustWindowRect(&winRect, WS_OVERLAPPEDWINDOW, FALSE);

	bmi = malloc(sizeof(BITMAPINFO) + 256 * sizeof(RGBQUAD));

	bmi->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi->bmiHeader.biWidth = 320;
	bmi->bmiHeader.biHeight = -200;
	bmi->bmiHeader.biPlanes = 1;
	bmi->bmiHeader.biBitCount = 8;
	bmi->bmiHeader.biClrUsed = 256;
	bmi->bmiHeader.biCompression = BI_RGB;

	hdcScreen = GetDC(NULL);
	backBitmap = CreateDIBSection(hdcScreen, bmi, DIB_RGB_COLORS, (void**)(&VGA), NULL, NULL);
	ReleaseDC(NULL, hdcScreen);

	wc.style = 0;
	wc.lpfnWndProc = WndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance_;
    wc.hIcon         = LoadIcon(hInstance_, MAKEINTRESOURCE(101));
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
    wc.lpszMenuName  = NULL;
    wc.lpszClassName = title;
    RegisterClass(&wc);

	globalWidth = 320;
	globalHeight = 200;
	windowWidth = width;
	windowHeight = height;
	globalBpp = 8;
							   
	hwnd = CreateWindow(title, title, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, winRect.right - winRect.left, winRect.bottom - winRect.top, NULL, NULL, hInstance_, NULL);
    ShowWindow(hwnd, SW_SHOW);
    UpdateWindow(hwnd);

    GetWindowRect(hwnd, &rectScreen);

	backbuffer = malloc(64000);	

	if(joyGetPos(0, &joypos) == JOYERR_NOERROR){ //joystick attached

            joyUsed = 1;

            if(!(fp = fopen("joy.ini", "r"))){ //no calibration file, calibrating now
                system("joytest");
                fp = fopen("joy.ini", "r");
            }

            fscanf(fp, "%d %d %d %d %d %d", &centerX, &centerY, &topX, &topY, &bottomX, &bottomY);
            fclose(fp);
        }
}

void DX_UPDATE(){
	while(PeekMessage(&Msg, hwnd, 0, 0, PM_REMOVE)){
            TranslateMessage(&Msg);
            DispatchMessage(&Msg);
        }
}

void waitblank(){ //hangs execution until vertical blanking
    while(!newFrame){
		DX_UPDATE();
	}
	newFrame = 0;
}

void flipbuffer(int fillcolor){ //copies the back buffer into VGA memory and then clears the back buffer for drawing
    memcpy(VGA, backbuffer, 64000);
    memset(backbuffer, fillcolor, 64000);
	InvalidateRect(hwnd, NULL, 0);
}

void setPalIndex(unsigned int index, unsigned char R, unsigned char G, unsigned char B){
	RGBQUAD col;
	RGBQUAD *willPalette = &(bmi->bmiColors[0]);

	HDC tempHdc = CreateCompatibleDC(NULL);
	SelectObject(tempHdc, backBitmap);
	col.rgbRed = R;
	col.rgbGreen = G;
	col.rgbBlue = B;
	willPalette[index] = col;

	SetDIBColorTable(tempHdc, index, 1, willPalette + index);
	DeleteDC(tempHdc);
}

void set_palette(char* palette){ //sets the VGA palette to the given array
    int i;

	for(i = 0; i < 768; i+=3){
		setPalIndex(i/3, palette[i] << 2, palette[i+1] << 2, palette[i+2] << 2);
	}
}

void draw_pixel(int x, int y, char c){
        if (x >= 0 && x < 320 && y >= 0 && y < 200){
                backbuffer[y * 320 + x] = c;
                //backbuffer[(y<<6) + (y<<8) + x] = c;
        }
}
void bitset_pixel(int x, int y, char c){
        if (x >= 0 && x < 320 && y >= 0 && y < 200){
                backbuffer[y * 320 + x] |= c;
                //backbuffer[(y<<6) + (y<<8) + x] = c;
        }
}

typedef struct Object{
    long size;
    char* bits;
    long spriteSize;
    void (*script)(struct Entity**);
} Object;


#define sgn(x) ((x<0)?-1:((x>0)?1:0)) /* macro to return the sign of a
                                         number */

void drawline(int x, int y, int x2, int y2, unsigned char color) {
    int j, decInc;
    int i;
    char *address;
    int addrInc;

        int yLonger=0;
        int incrementVal, endVal;
	
        int shortLen;
        int longLen;
        if ((x < 0 || y < 0 || x > 319 || y > 199) && (x2 < 0 || y2 < 0 || x2 > 319 || y2 > 199)) return;
        if (x2 < 0) {
        	//y2 = 0;
		y2 = y - ((y2 - y)*x) / (x2 - x);
		x2 = 0;
	}
	if (x < 0) {
		//y = 0;
		y = y2 - ((y - y2)*x2) / (x - x2);
		x = 0;
	}
	
        if (x2 > 319) {
        	//y2 = 0;
		y2 = y + ((y2 - y)*(320 - x)) / (x2 - x);
		x2 = 319;
	}
	if (x > 319) {
		//y = 0;
		y = y2 + ((y - y2)*(320 - x2)) / (x - x2);
		x = 319;
	}
	
	if (y2 < 0) {
        	//y2 = 0;
		x2 = x - ((x2 - x)*y) / (y2 - y);
		y2 = 0;
	}
	if (y < 0) {
		//y = 0;
		x = x2 - ((x - x2)*y2) / (y - y2);
		y = 0;
	}
	
        if (y2 > 199) {
        	//y2 = 0;
		x2 = x + ((x2 - x)*(200 - y)) / (y2 - y);
		y2 = 199;
	}
	if (y > 199) {
		//y = 0;
		x = x2 + ((x - x2)*(200 - y2)) / (y - y2);
		y = 199;
	}
        //if (x == 160 || y == 100 || x2 == 160 || y2 == 100) return;
	shortLen = y2-y;
	longLen = x2-x;
        if (abs(shortLen)>abs(longLen)) {
                int swap=shortLen;
                shortLen=longLen;
                longLen=swap;
                yLonger=1;
        }
        endVal=longLen;
        if (longLen<0) {
                incrementVal=-1;
                addrInc=-320;
                longLen=-longLen;
        } else{incrementVal=1;
            addrInc = 320;
        }
        if (longLen==0) decInc=0;
        else decInc = (shortLen << 16) / longLen;
        j=0;
            address = backbuffer + (x) + (y)*320;

        if (yLonger) {

                for (i=0;i!=endVal;i+=incrementVal,address+=addrInc) {
                        //draw_pixel(x+(j >> 16),y+i, color);
                        *(address+(j>>16)) = color;

                        j+=decInc;
                }
        } else {
                for (i=0;i!=endVal;i+=incrementVal,address+=incrementVal) {
                        *(address+(j>>16)*320) = color;
                        //*(address+(j>>10)+(j>>8)) = color;
                        //draw_pixel(x+i,y+(j >> 16), color);
                        j+=decInc;
                }
        }


}


void draw_line(short x1, short y1, short x2, short y2, char color)
{
    short i, dx, dy, sdx, sdy, dxabs, dyabs, x, y, px, py, address;

    dx = x2 - x1;      /* the horizontal distance of the line */
    dy = y2 - y1;      /* the vertical distance of the line */
    dxabs = abs(dx);
    dyabs = abs(dy);
    sdx = sgn(dx);
    sdy = sgn(dy);
    x = dyabs >> 1;
    y = dxabs >> 1;
    px = x1;
    py = y1;

        if(px < 0 || px > 319 || py < 0 || py > 199){
                return;
        }

        address = (py << 8) + (py << 6) + px;
        //back[address] = color;

    draw_pixel(px, py, color);
    //VGA[(py << 8) + (py << 6) + px] = color;


    if (dxabs >= dyabs) /* the line is more horizontal than vertical */
    {
        for (i = 0; i < dxabs; i++)
        {
            y += dyabs;
            if (y >= dxabs)
            {
                y -= dxabs;
                py += sdy;
                                address += (sdy) * 320;
            }
            px += sdx;

                        if(px < 0 || px > 319 || py < 0 || py > 199){
                return;
        }

                        address += sdx;
            draw_pixel(px, py, color);
        }
    }
    else /* the line is more vertical than horizontal */
    {
        for (i = 0; i < dyabs; i++)
        {
            x += dxabs;
            if (x >= dyabs)
            {
                x -= dyabs;
                px += sdx;
                                address += sdx;
            }
            py += sdy;

                        if(px < 0 || px > 319 || py < 0 || py > 199){
                return;
        }

                        address += (sdy) * 320;
            draw_pixel(px, py, color);
                        //back[address] = color;
        }
    }
}
