STARBLAZER II FOR WINDOWS 95/NT RELEASE NOTES
---------------------------------------------
Set the IP address, resolution, and ports to use for the client and server in their respective config files.
If you wish to configure a joystick, run joytest.exe with a joystick attached.